# agentic 扩展（@dongfanglin/openspec-agentic）

本扩展是 [OpenSpec](https://github.com/Fission-AI/OpenSpec) 的 agentic 工作流扩展。
标准流程（proposal → specs/design → plan → tasks → apply → verification → archive）
仍由 OpenSpec 执行；本扩展负责安装与升级、`agentic` schema、角色模型解析、E2E 留证与流程结构检查。

流程结构检查：`openspec-agentic workflow check --change <name> --stage plan|final|archive --json`。
它只读核对意图基线、需求覆盖引用、唯一门禁任务，以及最终目标、契约和证据摘要。
新 E2E 记录绑定规划契约，修改需求或计划后不能直接沿用旧记录。字段、兼容性和受控入口接法见
[检查协议](assets/openspec/schemas/agentic/procedures/workflow-check.md)，填写方式见
[完整变更示例](assets/openspec/schemas/agentic/procedures/minimal-change.md)。机械 PASS 不替代语义验收，
也不会自动拦截上游合并/归档；需要强制执行时由项目受控入口或 CI 调用。

## 安装

新项目一条命令：

```powershell
npx @dongfanglin/openspec-agentic@latest init . --tools codex
```

已经装过旧版 FluentSpec 的项目，一条命令完成迁移：

```powershell
npx @dongfanglin/openspec-agentic@latest update .
```

`init` 会依次完成：

1. 校验 Node / npm；
2. 把 `@fission-ai/openspec`（精确 `1.13.0`）与本扩展作为项目本地 devDependencies 安装；
3. 调用 `openspec init`；
4. 安装 `agentic` schema；
5. 合并 `openspec/config.yaml`（写入 `x-agentic.e2e` 开关，默认开启）；
6. 把 7 个角色初始化为 `@current`；
7. 安装 `.agents/skills/agentic-verify`；
8. 合并 `AGENTS.md`；
9. 写 `openspec/.agentic-install.json`；
10. 安装后校验。

任一步失败会回滚本次写入，不留下半成品。

`init` / `update` 的选项：

```powershell
npx @dongfanglin/openspec-agentic@latest update . --prefer openspec   # 新旧配置冲突时的显式裁决（update）
npx @dongfanglin/openspec-agentic@latest init . --force               # 覆盖被本地修改过的受管文件
npx @dongfanglin/openspec-agentic@latest init . --no-install          # 离线：假定两个依赖已在项目本地
npx @dongfanglin/openspec-agentic@latest init . --dry-run             # 只报告将要执行的动作
```

`--tools <host,...>` 透传给 `openspec init`（缺省为 `none`，不生成任何宿主专属文件）。

## 日常使用

宿主入口由 OpenSpec 提供，本扩展不新增入口：

- `/opsx:propose`
- `/opsx:apply`
- `/opsx:verify`
- `/opsx:archive`

终端里统一使用项目本地 OpenSpec（`init` 已把它装为项目本地依赖，因此不需要联网，也不会用到全局版本）：

```powershell
npx --quiet --no-install openspec status --change add-export
npx --quiet --no-install openspec instructions apply --change add-export --json
npx --quiet --no-install openspec validate add-export --strict
```

## 项目适配上下文

`openspec/config.yaml` 的 `context` 是稳定的项目画像，而不只是 agentic 配置说明。模板按
`Repository Structure`、`Standard Commands`、`Engineering Constraints`、`Runtime Environment`
组织待适配项；新项目不应把“未配置”当作事实或自行猜测，可先让隔离的 `environment/recon`
只读采集，再由 main 确认并写入。某次变更的文件范围、提交、工作包、临时资源和检查结果仍分别写入
`plan.md`、`tasks.md`、`verification.md`，不进入全局 context。

`init` / `update` 只补缺失配置并保留项目已有 context；通用工作流正文留在 schema，`all_done` 和
归档兜底留在 `operations.*.guidance`，角色模型留在 `x-agentic.roles`，E2E 开关留在 `x-agentic.e2e`。

## E2E 校验开关

`init` 会在 `openspec/config.yaml` 写入项目级开关 `x-agentic.e2e`，默认开启；存量项目执行一次
`update` 也会补上该键。

```yaml
x-agentic:
  e2e:
    enabled: true        # true：每次变更的 Main E2E mode 必须为 required
    command: ""          # 可选：项目真实 E2E 命令或入口
    maxAttempts: 3       # 同一变更连续失败的 E2E 重试上限；达到后停止自动重跑，须用户介入
```

- `maxAttempts`（默认 3）限制“E2E 失败 → 修复 → 重跑”的循环：同一变更连续失败达到该值后，
  `e2e run` 拒绝再开自动尝试并返回退出码 `2`，`e2e check` 判 `BLOCKED`，任务保持待办、
  阻断验收与归档；此时必须把问题、已尝试方案和证据交用户决策（提高上限或调整方案），
  不得删除或改写记录绕过。候选与最终阶段的失败尝试共同计数；人工记录（`--manual`）不执行命令，不计入。
- 开启（含缺省）时，agentic 变更的计划必须把 Main E2E 判为 `required`；只有用户显式批准降级，
  才能在 `plan.md` 的 `downgrade_approval` 记录批准原话、时间与来源后写 `not-applicable`。
  缺少该记录时计划无效，最终验收判 FAIL 并要求回写为 `required`。
- 关闭后，变更按原有判据自行选择 mode；`not-applicable` 仍需理由、依据和通过的非空替代检查。
- 读取当前开关（每次从磁盘读取，不缓存）：

```powershell
npx --quiet --no-install openspec-agentic e2e
npx --quiet --no-install openspec-agentic e2e --json
```

一致性检查（比对开关与每个**已完成**变更 `plan.md` 的 Main E2E 判据，并核对 required 变更是否已有成功执行记录）：

```powershell
npx --quiet --no-install openspec-agentic e2e check --change add-export   # 只查一个变更
npx --quiet --no-install openspec-agentic e2e check --json                # 查全部未归档变更
```

结论为 `PASS / FAIL / BLOCKED`；查全部模式下 `IN_PROGRESS`（任务未全部完成）与 `SKIPPED`（非 agentic
变更）不参与判定、不阻断，指定 `--change` 时未完成的变更判 `BLOCKED`（仅扩展拥有的最终 E2E 行与正在
执行的最终验收行 `[final-verification]` 允许保持待办）——单变更检查是 E2E 任务的完成
条件，不能让未完成状态被平凡判为 PASS；非 PASS 时命令以非零状态退出。它只做结构比对，不读
`verification.md`，不证明测试真实性；它自身不调用 archive，但判 PASS 时按 `[e2e-owned]` 回写的任务框会让
`openspec archive` 的"未完成任务阻断"生效。要防伪造仍需在 CI 或分支保护里重跑真实 E2E。
未指定 `--change` 时每个变更需要一次引擎调用，耗时随变更数增长。
只读核查（用户只要求检查、不更新进度）用 `--no-write`：检查照常判定但不回写 `[e2e-owned]` 行。

`--run-if-missing` 把检查升级为“确保执行”：`required` 变更没有新鲜成功记录时，先真实执行
`x-agentic.e2e.command` 并写记录，再给出判定（执行输出走 stderr，`--json` 的 stdout 仍是纯 JSON）。
需与 `--change` 连用；执行成功后若仍有除最终 E2E 行与最终验收行外的任务未勾完，判 `BLOCKED`，勾完复查才 PASS。

```powershell
npx --quiet --no-install openspec-agentic e2e check --change add-export --run-if-missing
```

流程内执行 E2E（这是 **apply 阶段的 E2E 任务**，与编码、代码检视同属一个阶段，不需要等 CI 或归档）：

```powershell
npx --quiet --no-install openspec-agentic e2e run --change add-export                              # 用 x-agentic.e2e.command
npx --quiet --no-install openspec-agentic e2e run --change add-export --stage candidate             # 候选阶段关键 E2E
npx --quiet --no-install openspec-agentic e2e run --change add-export --stage final                 # 最终主分支完整 E2E
npx --quiet --no-install openspec-agentic e2e run --change add-export --command "npm run e2e -- --grep @final"
npx --quiet --no-install openspec-agentic e2e run --change add-export --planning-root ..\main-repo    # 测试 worktree 中写回权威规划根
npx --quiet --no-install openspec-agentic e2e run --change add-export --manual --by tester-A --evidence reports/manual.md --result pass --cases E1,E2
```

规划根与代码目录分离：`--planning-root <路径>` 指定权威规划目录（存放 `openspec/changes` 的仓库/store），
命令仍在当前目录（代码 worktree）执行，记录统一写回权威变更目录。在独立测试 worktree 中执行时必须
显式传入主仓库的规划根，不要用当前目录推断变更位置，否则会解析到 worktree 中的非权威副本，
变更未提交时甚至找不到。`--planning-root` 同样作用于 `e2e check`，使检查与回写都针对权威规划。

命令在当前项目根执行，输出实时透传；退出码 `0` 通过、`1` E2E 失败、`2` 无法执行（缺命令/缺变更/参数不完整，或已达连续失败重试上限）。
无论通过还是失败，都会在变更目录下写一条机器记录（`openspec/changes/<变更>/e2e/run-*.json`，含命令、
退出码、提交、阶段与输出片段；人工路径记录执行人、证据引用、结果与用例范围），随变更一起归档。
执行前若变更目录之外的已跟踪文件存在未提交改动，`e2e run` 直接以退出码 `2` 拒绝执行：未提交内容无法绑定到
提交，记录会失效；`e2e check` 也会把“执行时产品已脏”或“记录之后又出现未提交改动”的记录判为失效。
`--stage candidate|final`
标注记录属于候选还是最终阶段，候选记录不满足最终门。人工路径用 `--result pass|fail|blocked` 与 `--cases <范围>`
显式记录结果与用例范围；人工记录不参与自动重试失败计数，一条人工 pass 不能隐式解除自动失败上限。
`required` 的变更若没有成功记录、
或者只有人工记录而项目已配置 `x-agentic.e2e.command`、或者成功记录的命令与配置不一致、
或者最近一次相关尝试失败（更新的失败不会被更早的 pass 掩盖）、或者只有候选阶段记录、
或者记录停在旧提交之后又改了代码，`e2e check` 都会判 FAIL。

`e2e check --change <变更>` 是 **最终 E2E 门禁行的完成条件**：它要求其余任务已完成，但允许扩展拥有的该行
与正在执行的最终验收行（`[final-verification]`）保持待办，避免二者互相死锁；判 PASS 时它自动勾选带 `[e2e-owned]` 标记的该行
（行级单一所有者：该行归扩展，其余任务行归主 Agent）；非 PASS 时该行由扩展回退（若原为已勾选）或保持待办，
两种 mode 都保留该行：`required` 时它是最终主分支完整 E2E 的门禁检查行；`not-applicable` 时它只确认
“不适用判据已按计划固化”，实际替代验证另列为主 Agent 拥有的任务（未完成时检查判 BLOCKED，不会被误勾）。
按"未完成任务阻断验收"的既有规则在 apply 内拦下，不在归档阶段补做。没有现成记录时先用
`--run-if-missing` 在流程内真实执行一次再判定。

这条自动回写给的是“流程阻断与默认确认提示”，不是不可绕过的 CLI 硬门：没跑 E2E/替代验证没做完时该框保持待办，
`openspec archive` 会据此提示并默认要求确认；但固定版本的上游引擎在确认后仍可用 `archive --yes` 带未完成任务继续，
本仓库的引擎契约测试也验证了该路径。因此复选框只是宿主流程义务，需要真正强制时使用受控归档入口、CI 或分支保护。
标记由任务模板生成；多条 `[e2e-owned]` 会使检查判 BLOCKED，不猜测。

开关是流程义务，不是 CLI 门禁：扩展只读取并校验配置、只读地核对计划与执行记录，不判断测试真实性，也不阻止归档；
判据正文见 agentic schema 的 plan/apply instruction 与 `procedures/acceptance.md`。

最终验收（tasks 的 `[final-verification]`）沿用 OpenSpec 的“复选框 + 提示词”模型：不勾选会被
`openspec archive` 的未完成任务门拦下，但扩展不对该标记做存在性/唯一性机器校验，也不校验验收结论的真实性，
与上游 `/opsx:verify` 同级；需要不可绕过的强制时同样落到 CI 或分支保护。

### E2E 并行执行

最终 Main E2E 的并行只在 `x-agentic.e2e.command` 内部发生，流程层仍是一个入口：

```powershell
# 每轮只调用一次；分片由命令内部并发
npx --quiet --no-install openspec-agentic e2e run --change add-export --stage final
```

- 把并发逻辑封进项目聚合入口（如 `node scripts/e2e-parallel.mjs`），由它内部派发分片并**汇总退出码**：
  任一分片失败或约定用例零执行即非零退出；各分片写独立报告供 `verification.md` 引用。
- **不要**按分片多次调用 `e2e run --stage final`：`e2e check` 只认最近一条 final 记录，多分会掩盖失败分片；
  且记录命令必须与 `x-agentic.e2e.command` 逐字一致，加分片参数会直接判 FAIL。
- 候选阶段用 `--stage candidate`，可按单元/分片分别留证，由主 Agent 汇总，不影响最终门。
- 分片必须隔离资源（数据库/schema、端口、账号、可写目录、外部服务）；无法隔离时串行或独占排队。

判据正文在 `openspec/schemas/agentic/` 的 plan/apply instruction 与 `E2E 并行执行（单入口）` 小节。

## 角色模型

只有修改模型时才需要扩展命令：

```powershell
npx openspec-agentic roles                                        # 读取并校验当前映射
npx openspec-agentic roles set reviewer provider/review-model     # 设置单个角色
npx openspec-agentic roles unset reviewer                         # 删除该角色条目
```

同样可以走项目本地解析：

```powershell
npx --quiet --no-install openspec-agentic roles set reviewer provider/review-model
npx --quiet --no-install openspec-agentic roles unset reviewer
```

配置只有一份，位于 `openspec/config.yaml` 的 `x-agentic.roles`：

```yaml
x-agentic:
  roles:
    main: "@current"
    coder: provider/fast-model
    reviewer: provider/review-model
```

7 个固定角色：`main`、`coder`、`integrator`、`tester`、`validator`、`reviewer`、`environment`。
`@current` 是扩展保留值，表示继承主会话当前模型；它不是宿主模型名，不会作为模型名传给宿主。
主流程在每次启用或派发其他角色前重新读取该映射，不缓存，也不生成宿主专用 agent 文件。

### 按档位推荐模型

判断与把关的岗位保持高档，实现、测试、集成等执行岗位用中档，环境类杂务用低档。
下例以 deepseek-v4 系列的 id 命名（该系列只有 `pro` 与 `flash` 两个型号），实际可用 id 由宿主决定；
`init` 写入的配置会在每个角色右侧带上这段建议。

| 档位 | 建议模型 | 角色 | 理由 |
| --- | --- | --- | --- |
| 高档 | `deepseek-v4-pro` | `main`、`reviewer` | 主流程协调、契约收敛与最终判断；独立检视与阻断判断，不能随实现档位下沉 |
| 中档 | `deepseek-v4-flash` | `coder`、`integrator`、`tester`、`validator` | 实现与修复、集成与合并、测试设计/编写/执行、探索性验证，按标准能力即可 |
| 低档 | `deepseek-v4-flash` | `environment` | 仓库/版本等事实侦察及环境准备、资源检查与清理，流程固定、判断量低；该系列没有更低型号，沿用 flash 即可 |

三档描述的是岗位所需能力，不是型号数量：判断与把关用 `pro`，执行与环境类用 `flash`。

```yaml
x-agentic:
  roles:
    main: deepseek-v4-pro          # 高档：主流程协调、契约收敛、最终判断
    coder: deepseek-v4-flash       # 中档：实现与缺陷修复
    integrator: deepseek-v4-flash  # 中档：集成与合并
    tester: deepseek-v4-flash      # 中档：测试设计、编写与执行
    validator: deepseek-v4-flash   # 中档：探索性验证与测试充分性判断
    reviewer: deepseek-v4-pro      # 高档：独立检视与阻断判断
    environment: deepseek-v4-flash # 低档：事实侦察、环境准备、资源检查与清理
```

### 任务下放与上下文隔离

`environment` 使用 [environment 角色指令](assets/openspec/schemas/agentic/roles/environment.md) 的
`recon` / `runtime` phase 承担仓库与目标引用、工具版本、命令入口、资源状态等机械事实采集，
以及运行资源准备、就绪检查和清理。每次派发使用新的任务级最小上下文；宿主支持时设置
`fork_turns="none"`，不传完整主对话、实现推理/自评、其他角色私有对话或全局证据汇总。

coder 可延续同一实现工作包的必要上下文；tester、validator 和每轮 reviewer 继续隔离产品编码对话。
各角色在来源处整理自身 handoff，权威 `plan.md`、`tasks.md`、`verification.md` 和跨报告判断仍由 main
单点维护，避免用另一个读取全部报告的 Agent 形成第二份全局上下文。

只想换个别角色时用 `roles set` 覆盖即可，其余保持 `@current` 继承主会话模型：

```powershell
npx --quiet --no-install openspec-agentic roles set reviewer deepseek-v4-pro
npx --quiet --no-install openspec-agentic roles set environment deepseek-v4-flash
```

`init` 会把上面的档位建议写在**每个角色右侧**；存量项目执行一次 `update` 也会逐角色补上
（已有行尾注释的角色不覆盖；旧版把建议写在 `roles:` 上方的项目不再重复添加）。
`roles set` 保持标量写法并保留该行尾注释。

模型是否生效由宿主决定：宿主必须把解析结果传入当次调用的原生 model 参数；
宿主无法指定模型时，必须报告该能力限制，不得声称配置已生效。

## 目录结构

```text
openspec/
  config.yaml              # 唯一的项目配置（x-agentic.roles 与 x-agentic.e2e 在此）
  .agentic-install.json    # 安装清单：扩展与引擎版本、受管文件哈希（doctor/update 据此判断漂移）
  schemas/agentic/         # 工作流定义
  specs/                   # 主规范
  changes/                 # 变更（归档后位于 changes/archive/）
.agents/skills/agentic-verify/
AGENTS.md
package.json
```

`openspec/changes/**` 与 `openspec/specs/**` 是项目自己的资产，扩展安装/升级/迁移时只读写受管文件。
运行期唯一例外是 E2E：扩展在变更目录下写自己的 `e2e/run-*.json` 记录，并只按 `[e2e-owned]` 标记回写最终
E2E 任务行（行级单一所有者）。
不再有 `fluentspec/` 目录，也不再有第二套配置。

## 旧项目迁移

`update` 会先识别四种状态：纯旧版、已完成迁移、新旧混合、用户改过受管 schema。迁移内容：

- `fluentspec/config.yaml` 的 `roles:` → `openspec/config.yaml` 的 `x-agentic.roles`；
- 旧配置的 `context` / `operations` 合并到 `openspec/config.yaml`；
- `fluentspec/schemas/agentic` → `openspec/schemas/agentic`。

冲突不静默覆盖，用 `--prefer openspec` 或 `--prefer legacy` 显式裁决。
旧配置保留为 `fluentspec/config.yaml.migrated`，目录不立即删除。
安装/升级/迁移不改写 `openspec/changes/**` 与 `openspec/specs/**`。

## 源码布局

- `assets/openspec/schemas/agentic/`：流程定义（`schema.yaml`、`templates`、`roles`、`procedures`、`tests`）
- `assets/openspec/config.yaml`：项目配置片段
- `src/`：`install`、`migrate`、`roles`、`e2e`、`e2e-check`、`manifest`、`project`、`cli`
- `bin/openspec-agentic.mjs`：CLI 入口
- `test/`、`scripts/`
- `.agents/skills/agentic-verify/` 与 `AGENTS.md`：安装时写入目标项目的模板（本仓库是包本身，不安装自己）

本仓库不包含 `openspec/`：它是包，不是使用本扩展的项目；试跑完整流程见文末「试跑完整流程」。

## 引擎兼容

依赖精确锁定 `@fission-ai/openspec` `1.13.0`（同时出现在 `peerDependencies` 与 `devDependencies`），
Node `>=20.19.0`。本扩展不把引擎当库 import，只消费它的 CLI 与 JSON 契约。
升级引擎是刻意变更：改锁定版本 → `npm ci` → 通过下面的发布门禁。

## 发布门禁

```powershell
npm test               # 单元与契约测试（test/*.test.mjs）
npm run test:workflow  # PowerShell 回归套件
npm run test:pack      # 真实 tarball 全流程
npm run verify         # 上述三者串行
```

`prepublishOnly` 绑定 `npm run verify`。`npm run test:workflow` 需要 Windows PowerShell 或 `pwsh`；
非 Windows 环境缺少 `pwsh` 时 `verify` 会失败（脚本会给出明确提示），请在 CI 中预装或单独拆分门禁。

## 试跑完整流程

`npm run test:pack` 会用真实 `npm pack` 产物在临时项目里跑完整流程（安装 → 逐阶段 instructions → 归档 →
旧项目迁移）；也可以在任意空项目里直接初始化：

```powershell
npx --quiet --no-install openspec --version         # 仓库内解析的是固定版本引擎
npx @dongfanglin/openspec-agentic@latest init . --tools codex
```
