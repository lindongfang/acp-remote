import crypto from 'node:crypto';
import { createReadStream } from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';

/**
 * 安装清单：记录扩展版本、引擎版本和受管文件哈希。
 * 受管文件 = 扩展拥有所有权的文件（agentic schema 与验收 skill）；
 * 合并进目标项目的文件（config.yaml、AGENTS.md、package.json）不在清单内，更新时不覆盖用户内容。
 */

export const MANIFEST_RELATIVE_PATH = 'openspec/.agentic-install.json';
export const SCHEMA_RELATIVE_PATH = 'openspec/schemas/agentic';
export const SKILL_RELATIVE_PATH = '.agents/skills/agentic-verify';

const MANAGED_ROOTS = [SCHEMA_RELATIVE_PATH, SKILL_RELATIVE_PATH];

function manifestPath(targetPath) {
  return path.join(targetPath, ...MANIFEST_RELATIVE_PATH.split('/'));
}

export async function exists(target) {
  try {
    await fs.access(target);
    return true;
  } catch {
    return false;
  }
}

async function hashFile(filePath) {
  const hash = crypto.createHash('sha256');
  for await (const chunk of createReadStream(filePath)) hash.update(chunk);
  return `sha256:${hash.digest('hex')}`;
}

/**
 * 目录内所有文件的相对路径（POSIX 分隔符）→ 哈希；目录不存在时返回空表。
 * 只处理普通文件与目录；符号链接条目不会被纳入漂移检测。
 */
async function hashTree(rootPath) {
  const files = {};
  if (!(await exists(rootPath))) return files;
  const walk = async (directory, prefix) => {
    const entries = await fs.readdir(directory, { withFileTypes: true });
    for (const entry of entries) {
      const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
      const absolute = path.join(directory, entry.name);
      if (entry.isDirectory()) await walk(absolute, relative);
      else if (entry.isFile()) files[relative] = await hashFile(absolute);
    }
  };
  await walk(rootPath, '');
  return files;
}

/** 受管文件的完整哈希表，键为项目相对路径。 */
export async function collectManagedFiles(targetPath) {
  const files = {};
  for (const relative of MANAGED_ROOTS) {
    const tree = await hashTree(path.join(targetPath, ...relative.split('/')));
    for (const [name, hash] of Object.entries(tree)) files[`${relative}/${name}`] = hash;
  }
  return files;
}

export async function readManifest(targetPath) {
  try {
    const manifest = JSON.parse(await fs.readFile(manifestPath(targetPath), 'utf8'));
    return typeof manifest === 'object' && manifest !== null ? manifest : null;
  } catch {
    return null;
  }
}

export async function writeManifest(targetPath, manifest) {
  const file = manifestPath(targetPath);
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
}

/** 单个受管根目录的完整哈希表（键为项目相对路径）。 */
export async function managedRootFiles(targetPath, relativeRoot) {
  const tree = await hashTree(path.join(targetPath, ...relativeRoot.split('/')));
  const files = {};
  for (const [name, hash] of Object.entries(tree)) files[`${relativeRoot}/${name}`] = hash;
  return files;
}

/**
 * 与实际文件比对受管文件；modified/missing 表示受管内容已被本地改动或删除。
 * 清单从未记录过某个受管根目录时，该目录属于「未受管」，不计入漂移（doctor 另行说明）。
 */
export async function diffManagedFiles(targetPath, manifest) {
  const recorded = manifest?.files ?? {};
  const current = await collectManagedFiles(targetPath);
  const modified = [];
  const missing = [];
  const added = [];
  const unmanagedRoots = [];
  for (const [name, hash] of Object.entries(recorded)) {
    if (!(name in current)) missing.push(name);
    else if (current[name] !== hash) modified.push(name);
  }
  const recordedRoots = new Set(MANAGED_ROOTS.filter((root) => Object.keys(recorded).some((name) => name.startsWith(`${root}/`))));
  for (const root of MANAGED_ROOTS) if (!recordedRoots.has(root)) unmanagedRoots.push(root);
  for (const name of Object.keys(current)) {
    if (name in recorded) continue;
    if (unmanagedRoots.some((root) => name.startsWith(`${root}/`))) continue;
    added.push(name);
  }
  return { modified, missing, added, unmanagedRoots };
}

/** 单个受管根目录的漂移；该根目录未记录任何受管文件时返回 null，交由调用方按未受管处理。 */
export async function diffManagedTree(targetPath, manifest, relativeRoot) {
  const recorded = manifest?.files ?? {};
  if (!Object.keys(recorded).some((name) => name.startsWith(`${relativeRoot}/`))) return null;
  const current = await hashTree(path.join(targetPath, ...relativeRoot.split('/')));
  const modified = [];
  const missing = [];
  const added = [];
  const expected = new Set();
  for (const [name, hash] of Object.entries(recorded)) {
    if (!name.startsWith(`${relativeRoot}/`)) continue;
    const relative = name.slice(relativeRoot.length + 1);
    expected.add(relative);
    if (!(relative in current)) missing.push(relative);
    else if (current[relative] !== hash) modified.push(relative);
  }
  for (const name of Object.keys(current)) if (!expected.has(name)) added.push(name);
  return { modified, missing, added };
}
