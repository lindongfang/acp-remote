import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import YAML from 'yaml';
import { block, contractDigest, digest, specFiles } from './workflow-contract.mjs';
import { resolveChangeRoot, evaluateRecordFreshness } from './e2e-run.mjs';
import { checkE2E } from './e2e-check.mjs';

const nonempty = (value) => typeof value === 'string' && value.trim().length > 0 && !/<[^>]+>|\bTBD\b/.test(value);
const list = (value) => Array.isArray(value) && value.length > 0 && value.every(nonempty);
const git = (root, args) => {
  const result = spawnSync('git', args, { cwd: root, encoding: 'utf8', windowsHide: true });
  if (result.error || result.status !== 0) throw new Error(`无法核实 Git：${args.join(' ')}`);
  return result.stdout.trim();
};

function sourceHeadings(text) {
  let requirement = '';
  return (text.match(/^#{1,6}\s+[^\r\n]+/gm) ?? []).map((heading) => {
    heading = heading.trim();
    if (/^#{1,3}\s/.test(heading)) requirement = heading.startsWith('### Requirement:') ? heading : '';
    return { heading, requirement: heading.startsWith('#### Scenario:') ? requirement : '' };
  });
}
const sourceKey = (file, entry) => `${file}\n${entry.requirement}\n${entry.heading}`;

/** Core audit is read-only. PASS means structural consistency, never semantic acceptance. */
export async function inspectWorkflow({ changeRoot, projectRoot, stage = 'plan' }) {
  const result = { result: 'PASS', stage, contractDigest: null, targetCommit: null, evidence: [], errors: [], boundary: '仅检查结构、引用和版本；不证明用户批准、角色独立性或测试真实性。' };
  const fail = (message) => result.errors.push(message);
  try {
    if (!['plan', 'final', 'archive'].includes(stage)) throw new Error('stage 只接受 plan、final、archive');
    const read = (file) => fs.readFile(path.join(changeRoot, file), 'utf8');
    const [proposal, plan, tasks, metadata] = await Promise.all([read('proposal.md'), read('plan.md'), read('tasks.md'), read('.openspec.yaml')]);
    const meta = YAML.parse(metadata);
    if (meta?.schema !== 'agentic') throw new Error('仅检查显式使用 agentic schema 的变更');
    if (meta.skip_specs !== undefined && typeof meta.skip_specs !== 'boolean') fail('skip_specs 必须是布尔值');
    const intent = block(proposal, 'agentic-intent');
    for (const field of ['sources', 'constraints', 'non_goals', 'success_criteria', 'decision_bounds', 'assumptions']) {
      if (!list(intent[field])) fail(`意图基线 ${field} 必须是非空字符串列表；无内容时显式记录“无”及依据`);
    }
    const coverage = block(plan, 'agentic-coverage');
    if (coverage.version !== 1) fail('agentic-coverage.version 必须为 1');
    if (!/^refs\/(heads|remotes)\/[^\s]+$/.test(coverage.target_ref ?? '')) fail('target_ref 必须是准确的 refs/heads/* 或 refs/remotes/* 引用');
    const taskRows = [...tasks.matchAll(/^\s*[-*]\s*\[([ xX])\]\s+(\d+\.\d+)\s+(.+)$/gm)];
    const allCheckboxes = [...tasks.matchAll(/^\s*[-*]\s*\[[ xX]\].*$/gm)];
    if (taskRows.length !== allCheckboxes.length || !taskRows.length) fail('每项任务须使用唯一的 X.Y 编号和非空描述');
    const taskIds = taskRows.map((row) => row[2]);
    if (new Set(taskIds).size !== taskIds.length) fail('任务编号重复');
    for (const marker of ['[e2e-owned]', '[final-verification]']) {
      if (taskRows.filter((row) => row[3].includes(marker)).length !== 1) fail(`必须存在唯一的 ${marker} 任务`);
    }
    if (taskRows.some((row) => row[3].includes('[e2e-owned]') && row[3].includes('[final-verification]'))) fail('E2E 门禁与最终验收不能是同一任务');
    if (stage !== 'plan') {
      for (const row of taskRows) if (row[1] === ' ' && !(stage === 'final' && row[3].includes('[final-verification]'))) fail(`任务 ${row[2]} 未完成`);
    }
    const rows = coverage.rows;
    if (!Array.isArray(rows) || rows.length === 0) throw new Error('覆盖索引 rows 不能为空');
    const ids = new Set();
    const mappedSources = new Set();
    const evidencePaths = new Set();
    for (const row of rows) {
      if (!nonempty(row.id) || ids.has(row.id)) fail('覆盖行 ID 缺失或重复');
      ids.add(row.id);
      if (!list(row.tasks) || row.tasks.some((id) => !taskIds.includes(id))) fail(`${row.id}: tasks 引用了不存在的任务`);
      if (!list(row.checks)) fail(`${row.id}: checks 不能为空`);
      else for (const check of row.checks) {
        if (!taskRows.some((task) => row.tasks?.includes(task[2]) && task[3].includes(`[${check}]`))) fail(`${row.id}: 检查 ${check} 未在关联任务中以 [${check}] 声明`);
      }
      if (!list(row.evidence)) fail(`${row.id}: evidence 必须列出计划证据路径`);
      else row.evidence.forEach((file) => evidencePaths.add(file));
      if (!nonempty(row.source?.path) || !nonempty(row.source?.heading)) { fail(`${row.id}: 缺少 source.path/heading`); continue; }
      const file = path.resolve(changeRoot, row.source.path);
      const source = await fs.readFile(file, 'utf8');
      const headings = sourceHeadings(source).filter((entry) => entry.heading === row.source.heading.trim()
        && (row.source.requirement === undefined || entry.requirement === row.source.requirement));
      if (headings.length !== 1) fail(`${row.id}: source.heading 必须精确匹配唯一标题；同名场景用 source.requirement 指定所属需求`);
      else mappedSources.add(sourceKey(file, headings[0]));
    }
    const specs = await specFiles(changeRoot);
    if (!meta.skip_specs && specs.length === 0) fail('未声明 skip_specs，但没有增量规范');
    if (meta.skip_specs && specs.length > 0) fail('skip_specs 与实际增量规范冲突');
    for (const file of specs) {
      const text = await fs.readFile(file, 'utf8');
      // Requirements and scenarios both need coverage, including removed requirements.
      for (const entry of sourceHeadings(text).filter((entry) => /^#{3,4}\s+(?:Requirement|Scenario):/.test(entry.heading))) {
        if (!mappedSources.has(sourceKey(file, entry))) fail(`未覆盖：${path.relative(changeRoot, file)} ${entry.requirement} ${entry.heading}`);
      }
      if (/^## RENAMED Requirements/m.test(text) && !mappedSources.has(sourceKey(file, { requirement: '', heading: '## RENAMED Requirements' }))) fail(`未覆盖重命名映射：${path.relative(changeRoot, file)}`);
    }
    result.contractDigest = await contractDigest(changeRoot);
    for (const file of evidencePaths) {
      try { result.evidence.push({ path: file, sha256: digest(await fs.readFile(path.resolve(changeRoot, file))) }); }
      catch (error) { if (stage !== 'plan' || error.code !== 'ENOENT') fail(`证据不可读取：${file}`); }
    }
    if (stage !== 'plan') {
      const assessment = block(await read('verification.md'), 'agentic-assessment');
      const target = git(projectRoot, ['rev-parse', '--verify', `${coverage.target_ref}^{commit}`]);
      const head = git(projectRoot, ['rev-parse', 'HEAD']);
      result.targetCommit = target;
      if (head !== target) fail('当前代码 HEAD 与计划目标引用不一致；请在目标版本 worktree 检查');
      if (assessment.target_commit !== target) fail('验收结论的 target_commit 已失效');
      if (assessment.contract_digest !== result.contractDigest) fail('验收结论的 contract_digest 已失效');
      if (assessment.result !== 'PASS') fail('当前证据验收结论不是 PASS');
      if (!nonempty(assessment.assessment_id)) fail('缺少 assessment_id');
      const freshness = evaluateRecordFreshness(projectRoot, changeRoot, { status: 'pass', commit: target });
      if (freshness.verdict !== 'fresh') fail(`目标代码状态不能验收：${freshness.reason}`);
      if (!Array.isArray(assessment.evidence)) fail('缺少验收证据摘要列表');
      else {
        const recordedPaths = assessment.evidence.map((entry) => entry.path);
        if (new Set(recordedPaths).size !== recordedPaths.length) fail('验收证据路径重复');
        for (const entry of result.evidence) {
          const saved = assessment.evidence.find((item) => item.path === entry.path);
          if (saved?.sha256 !== entry.sha256) fail(`证据缺失或摘要已改变：${entry.path}`);
        }
        // Additional review/resource reports are audited too, not just coverage rows.
        for (const entry of assessment.evidence) {
          if (!nonempty(entry.path) || entry.sha256 !== digest(await fs.readFile(path.resolve(changeRoot, entry.path)))) fail(`验收证据摘要不匹配：${entry.path}`);
        }
      }
      // Re-read to catch target movement during this audit; protected callers still need atomic integration.
      if (target !== git(projectRoot, ['rev-parse', '--verify', `${coverage.target_ref}^{commit}`])) fail('检查期间目标分支发生变化');
    }
  } catch (error) {
    result.result = result.errors.length ? 'FAIL' : 'BLOCKED';
    fail(error.message);
  }
  if (result.errors.length && result.result === 'PASS') result.result = 'FAIL';
  return result;
}

export async function checkWorkflow({ projectRoot, packageRoot, changeName, planningRoot = null, stage = 'plan' }) {
  const resolved = await resolveChangeRoot({ projectRoot, packageRoot, changeName, planningRoot });
  if (resolved.error) return { result: 'BLOCKED', errors: [resolved.error] };
  const result = await inspectWorkflow({ changeRoot: resolved.changeRoot, projectRoot, stage });
  if (stage !== 'plan' && result.result === 'PASS') {
    result.e2e = await checkE2E({ projectRoot, packageRoot, changeName, planningRoot, write: false });
    if (result.e2e.result !== 'PASS') result.result = result.e2e.result;
  }
  return result;
}
