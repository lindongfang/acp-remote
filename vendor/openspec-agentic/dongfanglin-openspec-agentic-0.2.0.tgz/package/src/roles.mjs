import fs from 'node:fs';
import path from 'node:path';
import YAML from 'yaml';

/**
 * 角色模型与 E2E 开关是项目配置：扩展只解析 openspec/config.yaml 的 x-agentic.roles
 * 与 x-agentic.e2e（后者见 ./e2e.mjs）。扩展不解释模型名，也不实现任何宿主适配器。
 */

export const ROLE_DEFINITIONS = [
  { id: 'main', name: '主 Agent' },
  { id: 'coder', name: '实现 Agent' },
  { id: 'integrator', name: '集成 Agent' },
  { id: 'tester', name: '测试 Agent' },
  { id: 'validator', name: '验证 Agent' },
  { id: 'reviewer', name: '检视 Agent' },
  { id: 'environment', name: '环境负责人' },
];

/** 扩展保留值：继承当前主会话正在使用的模型，而不是交给宿主解析的模型名。 */
const CURRENT_MODEL = '@current';

/** 扩展配置段；OpenSpec 只读取 schema/context/operations，其余字段由扩展拥有。 */
export const AGENTIC_SECTION = 'x-agentic';
export const CONFIG_VERSION = 1;
const AGENTIC_FIELDS = new Set(['configVersion', 'roles', 'e2e']);

export function defaultRoleModels() {
  return Object.fromEntries(ROLE_DEFINITIONS.map((role) => [role.id, CURRENT_MODEL]));
}

const ROLE_BY_ID = new Map(ROLE_DEFINITIONS.map((role) => [role.id, role]));

export function roleIds() {
  return ROLE_DEFINITIONS.map((role) => role.id);
}

export function isRoleId(id) {
  return ROLE_BY_ID.has(id);
}

function isPlainObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** 项目配置只位于 openspec/；扩展不读取其他位置的第二套配置。 */
export function projectConfigPath(projectRoot) {
  const paths = ['config.yaml', 'config.yml']
    .map((name) => path.join(projectRoot, 'openspec', name))
    .filter((candidate) => fs.existsSync(candidate));
  if (paths.length > 1) {
    throw new Error('openspec/ 同时存在 config.yaml 与 config.yml；请只保留一个配置文件后重试。');
  }
  if (paths.length === 1) return paths[0];
  return null;
}

function parseModel(id, value, errors) {
  const label = `${AGENTIC_SECTION}.roles.${id}`;
  if (typeof value === 'string') {
    const model = value.trim();
    if (model) return model;
    errors.push(`${label} 的模型不能为空`);
    return null;
  }
  if (!isPlainObject(value)) {
    errors.push(`${label} 必须是模型字符串或 { model: <模型> }`);
    return null;
  }
  const unknown = Object.keys(value).filter((field) => field !== 'model');
  if (unknown.length > 0) errors.push(`${label} 含未知字段：${unknown.join('、')}；仅支持 model`);
  if (typeof value.model !== 'string' || value.model.trim() === '') {
    errors.push(`${label}.model 必须是非空字符串`);
    return null;
  }
  return unknown.length === 0 ? value.model.trim() : null;
}

/**
 * 每次调用都从磁盘重新读取项目配置，不缓存结果；下一次角色启用立即采用新值。
 * 缺省角色返回 model: null，表示使用当前宿主的默认模型。
 */
export function resolveRoleModels({ projectRoot, strict = false, configText = undefined } = {}) {
  const configPath = projectConfigPath(projectRoot);
  const reportedPath = configPath === null ? null : path.relative(projectRoot, configPath).split(path.sep).join('/');
  const errors = [];
  const roles = ROLE_DEFINITIONS.map((role) => ({ ...role, model: null, configured: false, inheritCurrent: false }));

  if (!configPath && configText === undefined) {
    if (strict) errors.push('未找到 openspec/config.yaml');
    return { configPath: reportedPath, roles, configuredRoles: 0, errors };
  }

  let raw;
  try {
    raw = YAML.parse(configText ?? fs.readFileSync(configPath, 'utf8')) ?? {};
  } catch (error) {
    errors.push(`无法解析 ${reportedPath ?? '配置内容'}：${error instanceof Error ? error.message.split('\n')[0] : String(error)}`);
    return { configPath: reportedPath, roles, configuredRoles: 0, errors };
  }
  if (!isPlainObject(raw)) {
    errors.push(`${reportedPath ?? '配置内容'} 顶层必须是映射`);
    return { configPath: reportedPath, roles, configuredRoles: 0, errors };
  }

  const section = raw[AGENTIC_SECTION];
  if (section !== undefined && !isPlainObject(section)) {
    errors.push(`${AGENTIC_SECTION} 必须是映射`);
  } else if (section !== undefined) {
    for (const field of Object.keys(section)) {
      if (!AGENTIC_FIELDS.has(field)) errors.push(`${AGENTIC_SECTION} 含未知字段：${field}；仅支持 configVersion、roles、e2e`);
    }
    if (section.configVersion !== undefined && section.configVersion !== CONFIG_VERSION) {
      errors.push(`${AGENTIC_SECTION}.configVersion 必须为 ${CONFIG_VERSION}`);
    }
    const configured = section.roles ?? {};
    if (!isPlainObject(configured)) {
      errors.push(`${AGENTIC_SECTION}.roles 必须是“角色 ID → 模型”映射`);
    } else {
      for (const [id, value] of Object.entries(configured)) {
        if (!ROLE_BY_ID.has(id)) {
          errors.push(`${AGENTIC_SECTION}.roles 含未知角色 "${id}"；可用角色：${roleIds().join('、')}`);
          continue;
        }
        const model = parseModel(id, value, errors);
        if (model !== null) Object.assign(roles.find((role) => role.id === id), {
          model,
          configured: true,
          inheritCurrent: model === CURRENT_MODEL,
        });
      }
    }
  }

  if (strict) {
    for (const role of roles) if (!role.configured) errors.push(`--strict：角色 "${role.id}" 未配置模型`);
  }
  return { configPath: reportedPath, roles, configuredRoles: roles.filter((role) => role.configured).length, errors };
}

export function describeRoleModel(role) {
  return role.configured ? role.model : '宿主默认';
}

/**
 * 写入配置值。对象与数组必须先转成 YAML 节点：直接写入 JS 值会让后续
 * setIn/getIn 在该路径上拿不到集合节点。
 */
export function setConfigValue(document, pathParts, value) {
  const node = typeof value === 'object' && value !== null ? document.createNode(value) : value;
  document.setIn(pathParts, node);
  return node;
}

/**
 * 只改 openspec/config.yaml 的 x-agentic.roles.<角色>，保留文件其余内容与注释。
 * 写入前用同一条解析路径校验，避免落盘一份解析不通过的配置。
 */
export function writeRoleModel({ projectRoot, roleId, model }) {
  const configPath = projectConfigPath(projectRoot);
  if (!configPath) throw new Error('未找到 openspec/config.yaml；先运行 npx @dongfanglin/openspec-agentic@latest init .');
  const document = YAML.parseDocument(fs.readFileSync(configPath, 'utf8'), { lineWidth: 0 });
  if (document.errors.length > 0) throw new Error(`${configPath} 不是合法 YAML：${document.errors[0].message}`);

  const pathInDocument = [AGENTIC_SECTION, 'roles', roleId];
  const existing = document.getIn(pathInDocument, true);
  const isMapping = existing !== null && typeof existing === 'object' && typeof existing.items !== 'undefined';
  const inlineComment = existing !== null && typeof existing === 'object' && typeof existing.comment === 'string'
    ? existing.comment
    : undefined;
  if (model === null) {
    document.deleteIn(pathInDocument);
  } else if (isMapping) {
    document.setIn([...pathInDocument, 'model'], model);
  } else {
    // 标量写法保持不变（与安装写入的风格一致），并保留行尾建议注释。
    const node = document.createNode(model);
    if (inlineComment !== undefined) node.comment = inlineComment;
    document.setIn(pathInDocument, node);
  }
  if (!document.hasIn([AGENTIC_SECTION, 'configVersion'])) {
    document.setIn([AGENTIC_SECTION, 'configVersion'], CONFIG_VERSION);
  }

  const rolesNode = document.getIn([AGENTIC_SECTION, 'roles'], true);
  if (rolesNode && rolesNode.flow !== undefined) rolesNode.flow = false;
  const next = document.toString({ lineWidth: 0 });
  const check = resolveRoleModels({ projectRoot, configText: next });
  if (check.errors.length > 0) throw new Error(check.errors.join('；'));
  fs.writeFileSync(configPath, next, 'utf8');
  return configPath;
}
