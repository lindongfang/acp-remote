import { spawn, spawnSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';

/** 目标项目与外部工具：Node/npm 门槛、本地引擎定位、依赖安装和 OpenSpec CLI 调用。 */

export const ENGINE_PACKAGE = '@fission-ai/openspec';
export const AGENTIC_HEADING = '# Agentic workflow';
const ENGINE_RELATIVE_BIN = ['node_modules', '@fission-ai', 'openspec', 'bin', 'openspec.js'];

/** 包元数据与固定引擎版本；固定版本只写在 package.json，运行时不重复维护。 */
export async function loadPackageMetadata(packageRoot) {
  const metadata = await readJson(path.join(packageRoot, 'package.json'));
  if (metadata === null) throw new Error(`无法读取包元数据：${packageRoot}`);
  const enginePin = metadata.peerDependencies?.[ENGINE_PACKAGE] ?? metadata.devDependencies?.[ENGINE_PACKAGE];
  if (typeof enginePin !== 'string') {
    throw new Error(`包元数据缺少 ${ENGINE_PACKAGE} 的固定版本（peerDependencies 或 devDependencies）。`);
  }
  return { name: metadata.name, version: metadata.version, engines: metadata.engines, enginePin };
}

export async function exists(target) {
  try {
    await fs.access(target);
    return true;
  } catch {
    return false;
  }
}

/** 读取 JSON；文件不存在返回 null，存在但不可解析则抛出——静默降级会覆盖用户文件。 */
async function readJson(filePath) {
  let text;
  try {
    text = await fs.readFile(filePath, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw new Error(`无法读取 ${filePath}：${error.message}`);
  }
  try {
    // 部分 Windows 编辑器写入 UTF-8 BOM；JSON.parse 不接受，这里先剥离再解析。
    return JSON.parse(text.charCodeAt(0) === 0xFEFF ? text.slice(1) : text);
  } catch (error) {
    throw new Error(`${filePath} 不是合法 JSON（可能是 BOM 之外的语法问题或未解决的合并冲突）：${error.message}`);
  }
}

function readJsonSync(filePath) {
  try {
    const text = readFileSync(filePath, 'utf8');
    return JSON.parse(text.charCodeAt(0) === 0xFEFF ? text.slice(1) : text);
  } catch {
    return null;
  }
}

function parseVersion(text) {
  const match = /^v?(\d+)\.(\d+)\.(\d+)/.exec(String(text).trim());
  return match ? [Number(match[1]), Number(match[2]), Number(match[3])] : null;
}

function satisfiesMinimum(version, minimum) {
  for (let index = 0; index < 3; index += 1) {
    if (version[index] > minimum[index]) return true;
    if (version[index] < minimum[index]) return false;
  }
  return true;
}

/**
 * npm 调用方式。绝不按裸名经 cmd.exe 解析：cmd 先搜当前目录，项目里放一个 npm.cmd 即可劫持。
 * 优先用 npx/npm 注入的 npm_execpath；否则在 PATH 中定位 npm 的 JS 入口，一律用 node 直接执行。
 */
function npmInvocation() {
  const execPath = process.env.npm_execpath;
  if (typeof execPath === 'string' && execPath.endsWith('.js') && existsSync(execPath)) {
    return { command: process.execPath, prefix: [execPath] };
  }
  const names = process.platform === 'win32' ? ['npm.cmd', 'npm'] : ['npm'];
  for (const entry of (process.env.PATH ?? '').split(path.delimiter)) {
    if (entry.trim() === '' || !path.isAbsolute(entry)) continue;
    for (const name of names) {
      if (!existsSync(path.join(entry, name))) continue;
      const cli = path.join(entry, 'node_modules', 'npm', 'bin', 'npm-cli.js');
      if (existsSync(cli)) return { command: process.execPath, prefix: [cli] };
    }
  }
  throw new Error('未找到可用的 npm；请通过 npx 运行本扩展，或确认 npm 已加入 PATH。');
}

/** Node 与 npm 门槛：不足时给出可执行的升级提示，而不是留下半安装状态。 */
export function assertToolchain(engines) {
  const required = parseVersion(engines?.node?.replace(/^[^\d]*/, '') ?? '20.19.0');
  const current = parseVersion(process.version);
  if (!current || !satisfiesMinimum(current, required)) {
    throw new Error(`Node ${required.join('.')} 或更高版本必需；当前为 ${process.version}`);
  }
  const npm = npmInvocation();
  const probe = spawnSync(npm.command, [...npm.prefix, '--version'], { encoding: 'utf8', windowsHide: true });
  if (probe.error || probe.status !== 0) {
    throw new Error(`未找到可用的 npm（${npm.command}）；安装项目本地 OpenSpec 需要 npm。`);
  }
  const npmVersion = parseVersion(probe.stdout);
  if (!npmVersion || !satisfiesMinimum(npmVersion, [7, 0, 0])) {
    throw new Error(`npm 7 或更高版本必需；当前为 ${probe.stdout.trim() || '未知'}`);
  }
  return { node: process.version, npm: probe.stdout.trim() };
}

/**
 * 定位引擎 CLI：优先目标项目自身的 node_modules，其次包的安装位置，逐级向上查找。
 * 只接受版本等于包内固定版本的副本，避免按目录位置执行到无关或未锁定的引擎。
 */
function findEngineUpward(start, enginePin) {
  for (let directory = path.resolve(start); ; directory = path.dirname(directory)) {
    const candidate = path.join(directory, ...ENGINE_RELATIVE_BIN);
    if (existsSync(candidate)) {
      const metadata = readJsonSync(path.join(directory, 'node_modules', ...ENGINE_PACKAGE.split('/'), 'package.json'));
      if (metadata?.version === enginePin) return candidate;
    }
    if (path.dirname(directory) === directory) return null;
  }
}

export function resolveEngineCli(targetPath, packageRoot) {
  const pin = readJsonSync(path.join(packageRoot, 'package.json'));
  const enginePin = pin?.peerDependencies?.[ENGINE_PACKAGE] ?? pin?.devDependencies?.[ENGINE_PACKAGE];
  const engine = findEngineUpward(targetPath, enginePin) ?? (packageRoot ? findEngineUpward(packageRoot, enginePin) : null);
  if (engine) return engine;
  throw new Error(
    `未找到版本为 ${enginePin ?? '固定版本'} 的工作流引擎 ${ENGINE_PACKAGE}；`
    + '先在项目内运行 npx @dongfanglin/openspec-agentic@latest init . 或 npm install。',
  );
}

/** 项目本地引擎版本：只认目标项目 node_modules，避免把上层提升的副本当作项目锁定版本。 */
export async function projectEngineVersion(targetPath) {
  const metadata = readJsonSync(path.join(targetPath, 'node_modules', ...ENGINE_PACKAGE.split('/'), 'package.json'));
  return metadata?.version ?? null;
}

export async function projectPackageVersion(targetPath, packageName) {
  const metadata = readJsonSync(path.join(targetPath, 'node_modules', ...packageName.split('/'), 'package.json'));
  return metadata?.version ?? null;
}

export async function readPackageJson(targetPath) {
  return (await readJson(path.join(targetPath, 'package.json'))) ?? {};
}

async function writePackageJson(targetPath, metadata) {
  await fs.writeFile(path.join(targetPath, 'package.json'), `${JSON.stringify(metadata, null, 2)}\n`, 'utf8');
}

/** 目标项目没有 package.json 时创建一个私有骨架；不修改已有文件的任何字段。 */
export async function ensurePackageJson(targetPath) {
  if (await exists(path.join(targetPath, 'package.json'))) return false;
  const name = path.basename(path.resolve(targetPath)).toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '');
  await writePackageJson(targetPath, { name: name || 'project', version: '0.0.0', private: true });
  return true;
}

/** 写入规范化的 devDependencies；其余字段逐字保留。 */
export async function recordDevDependencies(targetPath, entries) {
  const metadata = await readPackageJson(targetPath);
  const devDependencies = { ...(metadata.devDependencies ?? {}) };
  let changed = false;
  for (const [name, spec] of Object.entries(entries)) {
    if (devDependencies[name] === spec) continue;
    devDependencies[name] = spec;
    changed = true;
  }
  if (!changed) return false;
  metadata.devDependencies = Object.fromEntries(
    Object.entries(devDependencies).sort(([left], [right]) => left.localeCompare(right)),
  );
  await writePackageJson(targetPath, metadata);
  return true;
}

export function installDependencies(targetPath, specs) {
  const npm = npmInvocation();
  const result = spawnSync(npm.command, [...npm.prefix, 'install', '--save-dev', '--save-exact', ...specs], {
    cwd: targetPath,
    stdio: 'inherit',
    windowsHide: true,
  });
  if (result.status !== 0) {
    throw new Error(`npm install --save-dev --save-exact ${specs.join(' ')} 失败（退出码 ${result.status ?? '未知'}）。`);
  }
}

/** 调用项目本地引擎；stdio 为 inherit 时子进程直接输出，否则返回捕获结果。 */
export function runEngine({ targetPath, packageRoot, args, capture = false }) {
  const cli = resolveEngineCli(targetPath, packageRoot);
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [cli, ...args], {
      cwd: targetPath,
      stdio: capture ? ['ignore', 'pipe', 'pipe'] : 'inherit',
    });
    let stdout = '';
    let stderr = '';
    if (capture) {
      child.stdout.on('data', (chunk) => { stdout += chunk; });
      child.stderr.on('data', (chunk) => { stderr += chunk; });
    }
    child.on('error', reject);
    child.on('exit', (code, signal) => {
      if (code === 0) resolve({ status: 0, stdout, stderr });
      else if (capture) resolve({ status: code ?? 1, stdout, stderr, signal });
      else reject(new Error(`OpenSpec ${args.join(' ')} 失败（${signal ?? `退出码 ${code}`}）。`));
    });
  });
}
