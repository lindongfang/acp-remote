import fs from 'node:fs';
import path from 'node:path';
import YAML from 'yaml';
import { AGENTIC_SECTION, projectConfigPath } from './roles.mjs';

/**
 * 项目级 E2E 校验开关是项目配置：扩展只解析 openspec/config.yaml 的 x-agentic.e2e。
 * 扩展不读变更目录，也不把开关变成 CLI 门禁。
 */

export const E2E_DEFAULTS = { enabled: true, command: '', maxAttempts: 3 };
const E2E_FIELDS = new Set(['enabled', 'command', 'maxAttempts']);
const E2E_SECTION_LABEL = `${AGENTIC_SECTION}.e2e`;

function isPlainObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * 每次调用都从磁盘重新读取，不缓存；未配置、未安装或缺失时返回默认（enabled: true），
 * 因此老项目升级后不会静默跳过 E2E。
 */
export function resolveE2EConfig({ projectRoot, configText = undefined } = {}) {
  const resolved = {
    configPath: null,
    enabled: E2E_DEFAULTS.enabled,
    command: E2E_DEFAULTS.command,
    maxAttempts: E2E_DEFAULTS.maxAttempts,
    configured: false,
    errors: [],
  };
  let configPath = null;
  try {
    configPath = projectConfigPath(projectRoot);
  } catch (error) {
    resolved.errors.push(error.message);
    return resolved;
  }
  // 与 roles --json 一致：对外报告相对于项目根、以 / 分隔的路径。
  resolved.configPath = configPath === null ? null : path.relative(projectRoot, configPath).split(path.sep).join('/');
  if (configText === undefined && configPath === null) return resolved;

  let raw;
  try {
    raw = YAML.parse(configText ?? fs.readFileSync(configPath, 'utf8')) ?? {};
  } catch (error) {
    resolved.errors.push(`无法解析 ${resolved.configPath ?? '配置内容'}：${error instanceof Error ? error.message.split('\n')[0] : String(error)}`);
    return resolved;
  }
  // 顶层或 x-agentic 不是映射时由 resolveRoleModels 报错，这里只关注 e2e 段。
  if (!isPlainObject(raw)) return resolved;
  const section = raw[AGENTIC_SECTION];
  if (section !== undefined && !isPlainObject(section)) return resolved;
  const e2e = section?.e2e;
  if (e2e === undefined) return resolved;
  if (!isPlainObject(e2e)) {
    resolved.errors.push(`${E2E_SECTION_LABEL} 必须是映射`);
    return resolved;
  }

  resolved.configured = true;
  for (const field of Object.keys(e2e)) {
    if (!E2E_FIELDS.has(field)) resolved.errors.push(`${E2E_SECTION_LABEL} 含未知字段：${field}；仅支持 enabled、command、maxAttempts`);
  }
  if (e2e.enabled !== undefined) {
    if (typeof e2e.enabled !== 'boolean') resolved.errors.push(`${E2E_SECTION_LABEL}.enabled 必须是布尔值`);
    else resolved.enabled = e2e.enabled;
  }
  if (e2e.command !== undefined) {
    if (typeof e2e.command !== 'string') resolved.errors.push(`${E2E_SECTION_LABEL}.command 必须是字符串`);
    else resolved.command = e2e.command.trim();
  }
  if (e2e.maxAttempts !== undefined) {
    if (!Number.isInteger(e2e.maxAttempts) || e2e.maxAttempts < 1) {
      resolved.errors.push(`${E2E_SECTION_LABEL}.maxAttempts 必须是 >= 1 的整数`);
    } else {
      resolved.maxAttempts = e2e.maxAttempts;
    }
  }
  return resolved;
}

/** 人类可读状态：区分“用户显式开启”与“缺省开启”。 */
export function describeE2EConfig(resolved) {
  if (!resolved.enabled) return '关闭';
  return resolved.configured ? '开启' : '开启（默认）';
}
