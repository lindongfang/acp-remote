import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import YAML from 'yaml';

export const digest = (value) => `sha256:${crypto.createHash('sha256').update(value).digest('hex')}`;

/** A single, explicitly named fenced block; never infer fields from surrounding prose. */
export function block(text, name) {
  const matches = [...text.matchAll(new RegExp('^```' + name + '\\s*\\r?\\n([\\s\\S]*?)^```\\s*$', 'gm'))];
  if (matches.length !== 1) throw new Error(`需要唯一的 ${name} 代码块`);
  const value = YAML.parse(matches[0][1]);
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`${name} 必须是 YAML 对象`);
  return value;
}

export async function specFiles(root) {
  const result = [];
  async function walk(directory) {
    for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
      const file = path.join(directory, entry.name);
      if (entry.isDirectory()) await walk(file);
      else if (entry.isFile() && entry.name.endsWith('.md')) result.push(file);
    }
  }
  try { await walk(path.join(root, 'specs')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  return result.sort();
}

/** Checkbox progress is not a contract change; task descriptions and all planning content are. */
export async function contractDigest(changeRoot) {
  const files = ['.openspec.yaml', 'proposal.md', 'design.md', 'plan.md', 'tasks.md'];
  files.push(...(await specFiles(changeRoot)).map((file) => path.relative(changeRoot, file).split(path.sep).join('/')));
  const contents = [];
  for (const file of files) {
    let text = (await fs.readFile(path.join(changeRoot, file), 'utf8')).replace(/\r\n/g, '\n');
    if (file === 'tasks.md') text = text.replace(/^(\s*[-*]\s*)\[[ xX]\]/gm, '$1[ ]');
    contents.push([file, text]);
  }
  // Existing contracts used by skip_specs (and other explicit sources) also participate.
  const plan = await fs.readFile(path.join(changeRoot, 'plan.md'), 'utf8');
  const index = block(plan, 'agentic-coverage');
  const sources = [...new Set((index.rows ?? []).map((row) => row.source?.path).filter((file) => typeof file === 'string'))].sort();
  for (const file of sources) contents.push([file, (await fs.readFile(path.resolve(changeRoot, file), 'utf8')).replace(/\r\n/g, '\n')]);
  return digest(JSON.stringify(contents));
}

/** Legacy changes retain their old E2E behavior; workflow check explicitly rejects missing contracts. */
export async function optionalContractDigest(changeRoot) {
  const plan = await fs.readFile(path.join(changeRoot, 'plan.md'), 'utf8').catch(() => '');
  if (!/^```agentic-coverage\s*$/m.test(plan)) return null;
  return contractDigest(changeRoot);
}
