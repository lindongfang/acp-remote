import fs from 'node:fs';
import fsPromises from 'node:fs/promises';
import path from 'node:path';
import YAML from 'yaml';
import { AGENTIC_SECTION } from './roles.mjs';
import { SCHEMA_RELATIVE_PATH } from './manifest.mjs';

/**
 * 旧版 FluentSpec 项目迁移：把 fluentspec/ 下的配置值合并到 openspec/config.yaml，
 * 并识别纯旧版 / 已完成迁移 / 混合 / 用户改过受管 schema 四种状态。
 * 迁移只读取旧配置并备份，不删除旧目录，也绝不改写 changes/** 与 specs/**。
 */

const LEGACY_DIR = 'fluentspec';
export const LEGACY_BACKUP_SUFFIX = '.migrated';

function legacyConfigPath(projectRoot) {
  const paths = ['config.yaml', 'config.yml']
    .map((name) => path.join(projectRoot, LEGACY_DIR, name))
    .filter((candidate) => fs.existsSync(candidate));
  if (paths.length > 1) {
    throw new Error('fluentspec/ 同时存在 config.yaml 与 config.yml；请只保留一个旧配置文件后重试。');
  }
  if (paths.length === 1) return paths[0];
  return null;
}

function legacySchemaPath(projectRoot) {
  return path.join(projectRoot, LEGACY_DIR, 'schemas', 'agentic');
}

/** 解析项目实际使用的配置文件名（config.yaml 优先，其次 config.yml）。 */
export function openspecConfigPath(projectRoot) {
  const paths = ['config.yaml', 'config.yml']
    .map((name) => path.join(projectRoot, 'openspec', name))
    .filter((candidate) => fs.existsSync(candidate));
  if (paths.length > 1) {
    throw new Error('openspec/ 同时存在 config.yaml 与 config.yml；请只保留一个配置文件后重试。');
  }
  if (paths.length === 1) return paths[0];
  return null;
}

function isPlainObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isSame(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}

function parseDocument(filePath) {
  const document = YAML.parseDocument(fs.readFileSync(filePath, 'utf8'), { lineWidth: 0 });
  if (document.errors.length > 0) throw new Error(`${filePath} 不是合法 YAML：${document.errors[0].message}`);
  return document;
}

/** 安装状态：openspec/ 与旧目录的实际存在情况，用于区分四种项目状态。 */
export function detectInstallState(projectRoot) {
  const legacyConfig = legacyConfigPath(projectRoot);
  return {
    openspecDir: fs.existsSync(path.join(projectRoot, 'openspec')),
    configPath: openspecConfigPath(projectRoot),
    schemaPath: path.join(projectRoot, ...SCHEMA_RELATIVE_PATH.split('/')),
    legacy: {
      configPath: legacyConfig,
      configRelative: legacyConfig === null ? null : path.relative(projectRoot, legacyConfig).split(path.sep).join('/'),
      schemaPath: legacySchemaPath(projectRoot),
      backupPath: legacyConfig === null ? null : `${legacyConfig}${LEGACY_BACKUP_SUFFIX}`,
    },
  };
}

/** 只提取要迁移的三类值；旧配置的其余字段（schema 等）不迁移。 */
export async function readLegacyConfig(configPath) {
  const document = parseDocument(configPath);
  const raw = document.toJS() ?? {};
  if (!isPlainObject(raw)) throw new Error(`${configPath} 顶层必须是映射`);
  if (raw.roles !== undefined && !isPlainObject(raw.roles)) {
    throw new Error(`${configPath} 的 roles 必须是“角色 ID → 模型”映射，迁移已停止。`);
  }
  if (raw.context !== undefined && typeof raw.context !== 'string') {
    throw new Error(`${configPath} 的 context 必须是字符串，迁移已停止。`);
  }
  if (raw.operations !== undefined && !isPlainObject(raw.operations)) {
    throw new Error(`${configPath} 的 operations 必须是映射，迁移已停止。`);
  }
  for (const [operation, settings] of Object.entries(raw.operations ?? {})) {
    if (!isPlainObject(settings)) {
      throw new Error(`${configPath} 的 operations.${operation} 必须是映射，迁移已停止。`);
    }
  }
  return {
    configPath,
    roles: raw.roles,
    context: raw.context,
    operations: raw.operations,
  };
}

/** 现有 openspec/config.yaml 中的对应值，用于冲突比较。 */
export async function readOpenspecValues(configPath) {
  if (configPath === null) return { roles: undefined, context: undefined, operations: undefined };
  const raw = parseDocument(configPath).toJS() ?? {};
  if (!isPlainObject(raw)) throw new Error(`${configPath} 顶层必须是映射`);
  const section = isPlainObject(raw[AGENTIC_SECTION]) ? raw[AGENTIC_SECTION] : {};
  return {
    roles: isPlainObject(section.roles) ? section.roles : undefined,
    context: typeof raw.context === 'string' ? raw.context : undefined,
    operations: isPlainObject(raw.operations) ? raw.operations : undefined,
  };
}

/**
 * 新旧配置并存时的裁决：相同或单侧缺失直接采用，真正冲突必须显式指定 --prefer。
 * 默认不静默覆盖任何一侧。
 */
export function adjudicateLegacy({ legacy, current, prefer }) {
  const conflicts = [];
  const adopt = { roles: {}, context: undefined, operations: {} };

  for (const [id, model] of Object.entries(legacy.roles ?? {})) {
    const existing = current.roles?.[id];
    if (existing === undefined) {
      adopt.roles[id] = model;
      continue;
    }
    if (isSame(existing, model)) continue;
    conflicts.push({ key: `${AGENTIC_SECTION}.roles.${id}`, legacy: model, openspec: existing, apply: () => { adopt.roles[id] = model; } });
  }
  if (legacy.context !== undefined && legacy.context.trim() !== '') {
    if (current.context === undefined || current.context.trim() === '') adopt.context = legacy.context;
    else if (current.context !== legacy.context) {
      conflicts.push({ key: 'context', legacy: legacy.context, openspec: current.context, apply: () => { adopt.context = legacy.context; } });
    }
  }
  for (const [operation, settings] of Object.entries(legacy.operations ?? {})) {
    if (!isPlainObject(settings)) continue;
    for (const [field, value] of Object.entries(settings)) {
      const existing = isPlainObject(current.operations?.[operation]) ? current.operations[operation][field] : undefined;
      if (existing === undefined) {
        adopt.operations[operation] = { ...(adopt.operations[operation] ?? {}), [field]: value };
        continue;
      }
      if (isSame(existing, value)) continue;
      conflicts.push({
        key: `operations.${operation}.${field}`,
        legacy: value,
        openspec: existing,
        apply: () => { adopt.operations[operation] = { ...(adopt.operations[operation] ?? {}), [field]: value }; },
      });
    }
  }

  if (conflicts.length > 0 && prefer === undefined) {
    const details = conflicts.map(({ key, legacy: left, openspec: right }) => `  - ${key}：旧配置 ${JSON.stringify(left)} / 现有配置 ${JSON.stringify(right)}`);
    throw new Error([
      'fluentspec/ 与 openspec/config.yaml 存在冲突，默认不静默覆盖：',
      ...details,
      '用 --prefer openspec 保留 openspec/config.yaml，或 --prefer legacy 采用旧配置。',
    ].join('\n'));
  }
  if (prefer === 'legacy') for (const conflict of conflicts) conflict.apply();

  return { conflicts, adopt, prefer: prefer ?? 'openspec' };
}

/** 备份旧配置；已有备份时不覆盖，避免丢掉更早的副本。 */
export async function backupLegacyConfig(configPath, { dryRun = false } = {}) {
  const backupPath = `${configPath}${LEGACY_BACKUP_SUFFIX}`;
  if (fs.existsSync(backupPath)) return { status: 'kept', path: backupPath };
  if (!dryRun) await fsPromises.rename(configPath, backupPath);
  return { status: dryRun ? 'would-rename' : 'renamed', path: backupPath };
}
