import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { E2E_DEFAULTS } from './e2e.mjs';
import { runEngine } from './project.mjs';
import { optionalContractDigest } from './workflow-contract.mjs';

/**
 * 在 spec 流程内执行项目 E2E 并留下机器生成的执行记录。
 * 记录随变更目录保存（归档时一并带走），供 e2e check 作为"确实跑过"的机器依据。
 */

const RECORDS_DIR = 'e2e';
const OUTPUT_TAIL_LIMIT = 4000;
const VALID_STATUS = new Set(['pass', 'fail']);

const stamp = (date) => date.toISOString().replace(/[-:.]/g, '');

/** 变更目录下的记录目录；不创建。 */
export function recordsDirOf(changeRoot) {
  return path.join(changeRoot, RECORDS_DIR);
}

/** 读取已有执行记录，按开始时间倒序；无法解析的文件以 status: 'invalid' 表示。 */
export async function readE2ERecords(changeRoot) {
  const directory = recordsDirOf(changeRoot);
  let names = [];
  try {
    names = await fs.readdir(directory);
  } catch {
    return [];
  }
  const records = [];
  for (const name of names.filter((entry) => entry.endsWith('.json')).sort()) {
    const file = path.join(directory, name);
    try {
      const record = JSON.parse(await fs.readFile(file, 'utf8'));
      records.push({ ...record, file, valid: record?.status !== undefined && typeof record === 'object' });
    } catch (error) {
      records.push({ file, valid: false, status: 'invalid', error: error instanceof Error ? error.message : String(error) });
    }
  }
  const key = (record) => String(record.finishedAt ?? record.startedAt ?? record.file ?? '');
  return records.sort((left, right) => key(right).localeCompare(key(left)));
}

/**
 * 从最新记录往前统计连续失败尝试数：遇到非 fail（含 pass）或无法解析的记录即停止。
 * 只统计自动执行记录——人工记录（kind: 'manual'）不参与自动重试计数，
 * 因此一条人工 pass/fail 都不能隐式解除或清零自动失败上限。
 * 用于限制“E2E 失败 → 修复 → 重跑”的循环次数，避免自动重跑死循环。
 */
export function consecutiveFailures(records) {
  let count = 0;
  for (const entry of records) {
    if (entry.kind === 'manual') continue;
    if (entry.valid === false || entry.status !== 'fail') break;
    count += 1;
  }
  return count;
}

function gitValue(projectRoot, args) {
  const result = spawnSync('git', args, { cwd: projectRoot, encoding: 'utf8', windowsHide: true });
  if (result.error || result.status !== 0) return null;
  return result.stdout.trim() || null;
}

/** 记录执行时的提交与工作区是否干净；无 git 时返回 null。 */
function gitSnapshot(projectRoot) {
  const commit = gitValue(projectRoot, ['rev-parse', 'HEAD']);
  if (commit === null) return { commit: null, dirty: null };
  const status = gitValue(projectRoot, ['status', '--porcelain']);
  return { commit, dirty: status !== null && status.length > 0 };
}

/**
 * 目标变更目录：交给引擎解析，避免自行拼规划根。
 * planningRoot 是权威规划根（存放 openspec/changes 的仓库/store）；缺省时为 projectRoot。
 * 测试 worktree 必须显式传入主仓库的规划根，否则会解析到 worktree 中的非权威副本。
 */
export async function resolveChangeRoot({ projectRoot, packageRoot, changeName, planningRoot = null }) {
  if (changeName === null) return { error: '需要 --change <name> 指定变更；执行记录按变更保存。' };
  const engineRoot = planningRoot ?? projectRoot;
  const status = await runEngine({ targetPath: engineRoot, packageRoot, args: ['status', '--change', changeName, '--json'], capture: true });
  const start = status.stdout.indexOf('{');
  const payload = status.status === 0 && start !== -1 ? JSON.parse(status.stdout.slice(start)) : null;
  if (payload === null || typeof payload.changeRoot !== 'string' || typeof payload.schemaName !== 'string') {
    return { error: `无法定位变更 "${changeName}"（openspec status 退出码 ${status.status}）。` };
  }
  return { changeRoot: payload.changeRoot, schemaName: payload.schemaName };
}

async function writeRecord(changeRoot, record) {
  const directory = recordsDirOf(changeRoot);
  await fs.mkdir(directory, { recursive: true });
  const base = `run-${stamp(new Date())}`;
  // 独占写入：并行分片/--run-if-missing 同时写记录时不得静默覆盖，同名则加序号重试。
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const file = path.join(directory, `${base}${attempt === 0 ? '' : `-${attempt}`}.json`);
    try {
      await fs.writeFile(file, `${JSON.stringify(record, null, 2)}\n`, { encoding: 'utf8', flag: 'wx' });
      return file;
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
    }
  }
  throw new Error(`无法写入 E2E 执行记录：${base} 已存在过多同刻记录。`);
}

/**
 * 执行项目 E2E 并写入记录。
 * 自动执行使用 x-agentic.e2e.command（可用 --command 覆盖），输出实时透传并保留结尾片段；
 * 人工执行只记录执行人与证据引用，不运行任何命令。
 * stage 标记记录属于候选还是最终阶段：候选记录不会被 e2e check 当作最终 E2E 门（G2）。
 */
export async function runE2E({
  projectRoot, packageRoot, changeName = null, command = null, manual = false,
  executor = null, evidence = null, notes = null, stage = null, settings = null, stream = 'stdout',
  planningRoot = null, result = null, cases = null,
}) {
  const resolved = await resolveChangeRoot({ projectRoot, packageRoot, changeName, planningRoot });
  if (resolved.error !== undefined) return { status: 'blocked', reason: resolved.error };

  const { changeRoot } = resolved;
  let contractDigest;
  try { contractDigest = await optionalContractDigest(changeRoot); }
  catch (error) { return { status: 'blocked', reason: `无法固定规划契约：${error.message}` }; }
  // 重试上限：连续失败达到 x-agentic.e2e.maxAttempts 时拒绝再开一次自动尝试，
  // 防止“修复 → 重跑”无限循环；人工记录不执行命令，不受此限。
  // 这是读-算-写检查，非跨进程锁：同时启动的并发尝试可能各读到未达上限。
  // 最终 E2E 已采用单入口（分片在命令内部并行），候选分片并发时该计数为近似值。
  if (!manual) {
    const maxAttempts = Number.isInteger(settings?.maxAttempts) ? settings.maxAttempts : E2E_DEFAULTS.maxAttempts;
    const failures = consecutiveFailures(await readE2ERecords(changeRoot));
    if (failures >= maxAttempts) {
      return {
        status: 'blocked',
        changeRoot,
        reason: `E2E 已连续失败 ${failures} 次，达到重试上限 ${maxAttempts} 次（x-agentic.e2e.maxAttempts）；停止自动重跑，须用户介入（提高上限或调整方案）后再执行。`,
      };
    }
  }
  const startedAt = new Date().toISOString();
  const snapshot = gitSnapshot(projectRoot);
  // 只有变更目录之外的未提交改动才影响“记录绑定到的提交”；规划/证据文件不算。
  const productDirty = uncommittedOutside(projectRoot, changeRoot);
  const dirtySummary = productDirty === null ? '' : productDirty.slice(0, 3).join('、') + (productDirty.length > 3 ? '…' : '');

  if (manual) {
    if (executor === null || executor.trim() === '' || evidence === null || evidence.trim() === '') {
      return { status: 'blocked', reason: '人工记录需要 --by <执行人> 与 --evidence <证据引用>。' };
    }
    const manualResult = result ?? 'pass';
    if (!['pass', 'fail', 'blocked'].includes(manualResult)) {
      return { status: 'blocked', reason: `人工记录结果非法：${manualResult}（仅接受 pass、fail、blocked）。` };
    }
    if (productDirty !== null && productDirty.length > 0) {
      return {
        status: 'blocked',
        changeRoot,
        reason: `人工执行前工作区存在变更目录之外的未提交改动：${dirtySummary}；记录无法绑定到具体提交，请先提交或还原后再记录。`,
      };
    }
    const record = {
      change: changeName,
      contractDigest,
      kind: 'manual',
      stage,
      status: manualResult,
      result: manualResult,
      cases: cases ?? null,
      command: null,
      exitCode: null,
      startedAt,
      finishedAt: new Date().toISOString(),
      durationMs: 0,
      commit: snapshot.commit,
      dirty: snapshot.dirty,
      workspaceDirty: productDirty ?? [],
      executor: executor.trim(),
      evidence: evidence.trim(),
      notes: notes ?? null,
      outputTail: '',
    };
    const file = await writeRecord(changeRoot, record);
    return { status: manualResult, kind: 'manual', record, recordPath: file, changeRoot };
  }

  // 产品代码脏状态：提交信息无法代表实际被测内容，执行前直接拒绝而不是留下无法核对的记录。
  if (productDirty !== null && productDirty.length > 0) {
    return {
      status: 'blocked',
      changeRoot,
      reason: `E2E 执行前工作区存在变更目录之外的未提交改动：${dirtySummary}；未提交内容无法绑定到提交，请先提交或还原后再执行。`,
    };
  }

  const effective = (command ?? settings?.command ?? '').trim();
  if (effective === '') {
    return {
      status: 'blocked',
      reason: '未配置 E2E 命令：请在 openspec/config.yaml 的 x-agentic.e2e.command 写入项目真实入口，或用 --command 指定，或改用 --manual 记录人工执行。',
    };
  }

  const child = spawn(effective, { cwd: projectRoot, shell: true, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  let tail = '';
  // stream='stdout'（默认，e2e run 原样透传）；'stderr' 把两类输出都导向 stderr，
  // 让 e2e check --json 的 stdout 保持纯 JSON；'capture' 只保留 outputTail。
  const stdoutTarget = stream === 'capture' ? null : stream === 'stderr' ? process.stderr : process.stdout;
  const stderrTarget = stream === 'capture' ? null : process.stderr;
  const collect = (chunk, target) => {
    if (target !== null) target.write(chunk);
    tail = `${tail}${chunk.toString()}`.slice(-OUTPUT_TAIL_LIMIT);
  };
  child.stdout.on('data', (chunk) => collect(chunk, stdoutTarget));
  child.stderr.on('data', (chunk) => collect(chunk, stderrTarget));
  const exitCode = await new Promise((resolve, reject) => {
    child.on('error', reject);
    child.on('close', (code) => resolve(code ?? 1));
  });
  const finishedAt = new Date();
  const record = {
    change: changeName,
    contractDigest,
    kind: 'automated',
    stage,
    status: exitCode === 0 ? 'pass' : 'fail',
    command: effective,
    exitCode,
    startedAt,
    finishedAt: finishedAt.toISOString(),
    durationMs: finishedAt.getTime() - new Date(startedAt).getTime(),
    commit: snapshot.commit,
    dirty: snapshot.dirty,
    workspaceDirty: productDirty ?? [],
    executor: null,
    evidence: null,
    notes: notes ?? null,
    outputTail: tail,
  };
  const file = await writeRecord(changeRoot, record);
  return { status: record.status, kind: 'automated', record, recordPath: file, changeRoot };
}

/**
 * 工作区中变更目录之外的未提交改动（仅提取路径）；无法判断时返回 null。
 * 用于让“记录之后又改了代码但未提交”同样使 E2E 证据失效。
 */
function uncommittedOutside(projectRoot, changeRoot) {
  const repoRoot = gitValue(projectRoot, ['rev-parse', '--show-toplevel']);
  const status = gitValue(projectRoot, ['status', '--porcelain']);
  if (repoRoot === null || status === null) return null;
  if (status === '') return [];
  const changeAbs = path.resolve(changeRoot);
  const projectAbs = path.resolve(projectRoot);
  const outside = [];
  for (const line of status.split('\n')) {
    if (line.trim() === '') continue;
    let file = line.slice(3).trim();
    if (file.includes(' -> ')) file = file.slice(file.lastIndexOf(' -> ') + 4).trim();
    if (file.startsWith('"') && file.endsWith('"')) file = file.slice(1, -1);
    const abs = path.resolve(repoRoot, file);
    // 只关心本项目内的改动；projectRoot 是更大仓库的子目录时，仓库其他部分的改动不影响本项目。
    const inProject = path.relative(projectAbs, abs);
    if (inProject === '' || inProject.startsWith('..') || path.isAbsolute(inProject)) continue;
    const inside = path.relative(changeAbs, abs);
    if (inside === '' || (!inside.startsWith('..') && !path.isAbsolute(inside))) continue;
    outside.push(inProject.split(path.sep).join('/'));
  }
  return outside;
}

/**
 * 成功记录对当前版本是否仍然有效：
 * 记录提交与 HEAD 相同 → 有效；否则比较两者之间变更目录之外的改动，有改动即失效。
 * 另：当前工作区若还有变更目录之外的未提交改动，HEAD 不代表被测状态，同样失效。
 * 无 git、缺提交信息或无法比较时返回无法判定。
 */
export function evaluateRecordFreshness(projectRoot, changeRoot, record) {
  if (!VALID_STATUS.has(record?.status) || typeof record?.commit !== 'string' || record.commit === '') {
    return { verdict: 'unknown', reason: '记录未包含提交信息' };
  }
  // 执行时产品代码已脏：提交号无法代表被测内容，即使之后还原且 HEAD 未变也不能判 fresh。
  if (Array.isArray(record.workspaceDirty) && record.workspaceDirty.length > 0) {
    const shown = record.workspaceDirty.slice(0, 3).join('、');
    return { verdict: 'stale', reason: `执行时工作区已有变更目录之外的未提交改动：${shown}${record.workspaceDirty.length > 3 ? '…' : ''}` };
  }
  const head = gitValue(projectRoot, ['rev-parse', 'HEAD']);
  if (head === null) return { verdict: 'unknown', reason: '无法读取当前提交（无 git 或仓库不可用）' };
  const uncommitted = uncommittedOutside(projectRoot, changeRoot);
  if (uncommitted !== null && uncommitted.length > 0) {
    const shown = uncommitted.slice(0, 3).join('、');
    return { verdict: 'stale', reason: `执行后工作区仍有未提交改动：${shown}${uncommitted.length > 3 ? '…' : ''}` };
  }
  if (head === record.commit) return { verdict: 'fresh' };
  const diff = gitValue(projectRoot, ['diff', '--name-only', `${record.commit}..HEAD`]);
  if (diff === null) return { verdict: 'unknown', reason: `无法比较 ${record.commit}..HEAD` };
  const relativeChangeDir = path.relative(projectRoot, changeRoot).split(path.sep).join('/');
  const outside = diff.split('\n').map((line) => line.trim()).filter(Boolean)
    .filter((file) => !(relativeChangeDir !== '' && file.startsWith(`${relativeChangeDir}/`)));
  if (outside.length === 0) return { verdict: 'fresh' };
  return { verdict: 'stale', reason: `执行后又有改动：${outside.slice(0, 3).join('、')}${outside.length > 3 ? '…' : ''}` };
}
