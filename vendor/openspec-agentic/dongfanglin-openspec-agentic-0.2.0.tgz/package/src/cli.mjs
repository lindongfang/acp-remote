import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';
import YAML from 'yaml';
import { install } from './install.mjs';
import { describeRoleModel, isRoleId, projectConfigPath, resolveRoleModels, roleIds, writeRoleModel } from './roles.mjs';
import { describeE2EConfig, resolveE2EConfig } from './e2e.mjs';
import { checkE2E } from './e2e-check.mjs';
import { checkWorkflow } from './workflow-check.mjs';
import { runE2E as executeE2E } from './e2e-run.mjs';
import { diffManagedFiles, MANIFEST_RELATIVE_PATH, readManifest, SCHEMA_RELATIVE_PATH, SKILL_RELATIVE_PATH } from './manifest.mjs';
import {
  AGENTIC_HEADING, ENGINE_PACKAGE, assertToolchain, exists, loadPackageMetadata, projectEngineVersion, runEngine,
} from './project.mjs';

/**
 * 扩展 CLI：管理安装、升级、诊断、角色模型、E2E 留证与流程结构检查。
 * 标准工作流命令一律走项目本地 OpenSpec（npx --quiet --no-install openspec ...），本 CLI 不转发。
 */

const packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const valueOptions = new Set(['--tools', '--prefer']);
const help = `Usage:
  npx @dongfanglin/openspec-agentic@latest init [path] [--tools <host,...>] [--force] [--no-install] [--dry-run]
  npx @dongfanglin/openspec-agentic@latest update [path] [--prefer openspec|legacy] [--force] [--no-install] [--dry-run]
  openspec-agentic doctor [path]
  openspec-agentic workflow check --change <name> [--stage plan|final|archive] [--planning-root <path>] [--json]
  openspec-agentic roles [--json] [--strict]
  openspec-agentic roles set <role> <model>
  openspec-agentic roles unset <role>
  openspec-agentic e2e [--json]
  openspec-agentic e2e check [--change <name>] [--json] [--run-if-missing] [--planning-root <path>] [--no-write]
  openspec-agentic e2e run --change <name> [--command "<cmd>"] [--stage candidate|final] [--planning-root <path>] [--json]
  openspec-agentic e2e run --change <name> --manual --by <执行人> --evidence <证据引用> [--result pass|fail|blocked] [--cases <范围>] [--stage candidate|final] [--notes <说明>]

Workflow commands run through the project-local engine:
  npx --quiet --no-install openspec status --change <name>
  npx --quiet --no-install openspec instructions apply --change <name> --json
  npx --quiet --no-install openspec validate <name> --strict

Role models are project configuration in openspec/config.yaml (x-agentic.roles).
workflow check is read-only: plan checks intent/coverage/tasks; final and archive also check target,
contract and evidence hashes and E2E. final permits only the final-verification task to be pending;
archive requires every task complete. PASS is structural consistency, not proof of semantic acceptance.
The extension does not bind them to a specific agent host.
x-agentic.e2e is the project-level E2E switch (enabled by default); the e2e command only reads it.
e2e run executes the project E2E entry (x-agentic.e2e.command, or --command) inside the running change
and writes a machine record under the change directory; a failing run is recorded too. --stage candidate|final
tags whether the record belongs to a candidate or the final gate; candidate records never satisfy e2e check's
final-E2E gate. Exit codes: 0 pass, 1 E2E failed, 2 could not run (missing command/change/args, dirty product
tree or retry cap).
--planning-root points at the authoritative planning repo (where openspec/changes lives); the E2E command still
runs in the current directory. Test worktrees must pass it so records return to the authoritative change.
e2e check compares the switch with each completed change's plan.md, and for required changes demands a
successful record from e2e run. With --change the change must be fully complete (in-progress is a non-PASS),
and --run-if-missing executes the project E2E command when no fresh passing record exists. On PASS it ticks
the [e2e-owned] final-E2E task line so openspec archive's incomplete-task gate applies. It reads no prose
evidence and does not block archiving by itself. --no-write performs a pure read-only check (no task
back-write) for read-only verification.
x-agentic.e2e.maxAttempts (default 3) caps consecutive failing E2E attempts: once reached, e2e run refuses
new attempts and e2e check reports BLOCKED until a user raises the limit or changes the approach.
`;

function parseOptions(args, { allowPrefer = false } = {}) {
  const options = { dryRun: false, force: false, noInstall: false, tools: undefined, prefer: undefined };
  const positionals = [];
  for (let index = 0; index < args.length; index += 1) {
    const argument = args[index];
    if (argument === '--dry-run') { options.dryRun = true; continue; }
    if (argument === '--force') { options.force = true; continue; }
    if (argument === '--no-install') { options.noInstall = true; continue; }
    if (valueOptions.has(argument)) {
      if (index + 1 >= args.length) throw new Error(`${argument} requires a value.`);
      const value = args[index + 1];
      index += 1;
      if (argument === '--tools') options.tools = value;
      else if (!allowPrefer) throw new Error('--prefer is only supported by update.');
      else if (value !== 'openspec' && value !== 'legacy') throw new Error('--prefer 只接受 openspec 或 legacy。');
      else options.prefer = value;
      continue;
    }
    if (argument.startsWith('-')) throw new Error(`Unknown option "${argument}".\n\n${help}`);
    positionals.push(argument);
  }
  if (positionals.length > 1) throw new Error('Only one target path may be provided.');
  return { options, target: positionals[0] ?? '.' };
}

function reportInstall(result) {
  for (const message of result.messages) process.stdout.write(`openspec-agentic: ${message}\n`);
  const { summary } = result;
  process.stdout.write(`OpenSpec: ${summary.openspec ?? 'unknown'}\n`);
  process.stdout.write(`Agentic schema: ${summary.schema}\n`);
  process.stdout.write(`Default schema: ${summary.defaultSchema}\n`);
  process.stdout.write(`Roles: ${summary.roles} configured\n`);
  process.stdout.write(`Agentic verification skill: ${summary.skill}\n`);
  process.stdout.write(`Schema validation: ${summary.schemaValidation}\n`);
  process.stdout.write(`Installation: ${summary.installation}\n`);
  if (result.failure) process.stderr.write(`openspec-agentic: 错误: ${result.failure.message}\n`);
  if (summary.installation !== 'PASS') process.exitCode = 1;
}

async function runInstallCommand(mode, args) {
  const { options, target } = parseOptions(args, { allowPrefer: mode === 'update' });
  const targetPath = path.resolve(process.cwd(), target);
  const result = await install({ mode, targetPath, packageRoot, ...options });
  reportInstall(result);
}

function parseRolesArguments(args) {
  const options = { json: false, strict: false, action: null, roleId: null, model: null };
  const positionals = [];
  for (const argument of args) {
    if (argument === '--json') options.json = true;
    else if (argument === '--strict') options.strict = true;
    else if (argument.startsWith('-')) throw new Error(`Unknown roles option "${argument}".`);
    else positionals.push(argument);
  }
  if (positionals.length > 0) {
    [options.action, options.roleId, options.model] = positionals;
    if (options.action !== 'set' && options.action !== 'unset') throw new Error(`Unknown roles subcommand "${options.action}".`);
    if (!options.roleId) throw new Error(`roles ${options.action} 需要角色 ID。可用角色：${roleIds().join('、')}`);
    if (!isRoleId(options.roleId)) throw new Error(`未知角色 "${options.roleId}"；可用角色：${roleIds().join('、')}`);
    if (options.action === 'set' && !options.model) throw new Error('roles set 需要模型名。');
    if (positionals.length > 3) throw new Error('roles set 只接受 <角色> <模型> 两个参数。');
  }
  return options;
}

function runRoles(args, projectRoot = process.cwd()) {
  const options = parseRolesArguments(args);
  if (options.action !== null) {
    const configPath = writeRoleModel({ projectRoot, roleId: options.roleId, model: options.action === 'set' ? options.model : null });
    process.stdout.write(`openspec-agentic: ${options.action === 'set' ? '已设置' : '已删除'} x-agentic.roles.${options.roleId} in ${path.relative(projectRoot, configPath) || configPath}；下一次角色启用时生效\n`);
    return;
  }
  const resolved = resolveRoleModels({ projectRoot, strict: options.strict });
  for (const error of resolved.errors) process.stderr.write(`openspec-agentic: 错误: ${error}\n`);
  if (options.json) process.stdout.write(`${JSON.stringify(resolved, null, 2)}\n`);
  else {
    process.stdout.write(`agentic 角色模型 · ${resolved.configPath ?? '未找到 openspec/config.yaml'}\n`);
    for (const role of resolved.roles) process.stdout.write(`- ${role.id} (${role.name}): ${describeRoleModel(role)}\n`);
  }
  if (resolved.errors.length > 0) process.exitCode = 1;
}

/** `e2e` 与 `e2e check` 共用选项解析；`--change` 与 `--run-if-missing` 只对 check 有效。 */
function parseE2EOptions(args, { allowChange = false, allowRunIfMissing = false } = {}) {
  const options = { json: false, change: null, runIfMissing: false, planningRoot: null, noWrite: false };
  const positionals = [];
  for (let index = 0; index < args.length; index += 1) {
    const argument = args[index];
    if (argument === '--json') { options.json = true; continue; }
    if (argument === '--change') {
      if (!allowChange) throw new Error('--change 只适用于 openspec-agentic e2e check。');
      if (index + 1 >= args.length) throw new Error('--change requires a value.');
      options.change = args[index + 1];
      index += 1;
      continue;
    }
    if (argument === '--run-if-missing') {
      if (!allowRunIfMissing) throw new Error('--run-if-missing 只适用于 openspec-agentic e2e check。');
      options.runIfMissing = true;
      continue;
    }
    if (argument === '--planning-root') {
      if (!allowChange) throw new Error('--planning-root 只适用于 openspec-agentic e2e check。');
      if (index + 1 >= args.length) throw new Error('--planning-root requires a value.');
      options.planningRoot = args[index + 1];
      index += 1;
      continue;
    }
    if (argument === '--no-write') {
      if (!allowChange) throw new Error('--no-write 只适用于 openspec-agentic e2e check。');
      options.noWrite = true;
      continue;
    }
    if (argument.startsWith('-')) throw new Error(`Unknown e2e option "${argument}".`);
    positionals.push(argument);
  }
  if (positionals.length > 0) throw new Error(`Unknown e2e argument "${positionals[0]}".`);
  return options;
}

/** 只读项目级 E2E 开关；不解析变更目录，因此不构成 E2E 门禁。 */
function runE2E(args, projectRoot = process.cwd()) {
  const options = parseE2EOptions(args);
  const resolved = resolveE2EConfig({ projectRoot });
  for (const error of resolved.errors) process.stderr.write(`openspec-agentic: 错误: ${error}\n`);
  if (options.json) {
    process.stdout.write(`${JSON.stringify(resolved, null, 2)}\n`);
  } else {
    process.stdout.write(`agentic E2E 校验开关 · ${resolved.configPath ?? '未找到 openspec/config.yaml'}\n`);
    process.stdout.write(`- enabled: ${resolved.enabled}（${describeE2EConfig(resolved)}）\n`);
    process.stdout.write(`- command: ${resolved.command || '未配置'}\n`);
    process.stdout.write(`- maxAttempts: ${resolved.maxAttempts}\n`);
  }
  if (resolved.errors.length > 0) process.exitCode = 1;
}

/** 比对项目开关与各变更 plan.md 记录的 Main E2E 判据；只做结构检查，不读测试证据。 */
async function runE2ECheck(args, projectRoot = process.cwd()) {
  const options = parseE2EOptions(args, { allowChange: true, allowRunIfMissing: true });
  if (options.runIfMissing && options.change === null) {
    throw new Error('--run-if-missing 需要 --change 指定单个变更，避免对全部在途变更自动执行 E2E。');
  }
  if (options.noWrite && options.runIfMissing) {
    throw new Error('--no-write 不能与 --run-if-missing 同时使用：执行 E2E 会写记录，不属于只读检查。');
  }
  const planningRoot = options.planningRoot === null ? null : path.resolve(process.cwd(), options.planningRoot);
  const result = await checkE2E({
    projectRoot,
    packageRoot,
    changeName: options.change,
    runIfMissing: options.runIfMissing,
    planningRoot,
    write: !options.noWrite,
  });
  for (const error of result.errors) process.stderr.write(`openspec-agentic: 错误: ${error}\n`);
  if (options.json) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  } else {
    process.stdout.write(`agentic E2E 一致性检查 · ${result.configPath ?? '未找到 openspec/config.yaml'}（enabled=${result.enabled}）\n`);
    for (const change of result.changes) process.stdout.write(`${change.result}  ${change.name}: ${change.reason}\n`);
    process.stdout.write(`E2E check: ${result.result}\n`);
  }
  if (result.result !== 'PASS') process.exitCode = 1;
}

/** `e2e run` 的选项；与 check 分开解析，避免两种用法互相污染。 */
function parseE2ERunArguments(args) {
  const valueOptions = new Map([
    ['--change', 'change'],
    ['--command', 'command'],
    ['--stage', 'stage'],
    ['--by', 'executor'],
    ['--evidence', 'evidence'],
    ['--notes', 'notes'],
    ['--planning-root', 'planningRoot'],
    ['--result', 'result'],
    ['--cases', 'cases'],
  ]);
  const options = { json: false, manual: false, change: null, command: null, stage: null, executor: null, evidence: null, notes: null, planningRoot: null, result: null, cases: null };
  for (let index = 0; index < args.length; index += 1) {
    const argument = args[index];
    if (argument === '--json') { options.json = true; continue; }
    if (argument === '--manual') { options.manual = true; continue; }
    const field = valueOptions.get(argument);
    if (field !== undefined) {
      if (index + 1 >= args.length) throw new Error(`${argument} requires a value.`);
      options[field] = args[index + 1];
      index += 1;
      continue;
    }
    if (argument.startsWith('-')) throw new Error(`Unknown e2e option "${argument}".`);
    throw new Error(`Unknown e2e argument "${argument}".`);
  }
  if (options.manual && options.command !== null) throw new Error('--manual 与 --command 不能同时使用。');
  if (!options.manual && (options.result !== null || options.cases !== null)) throw new Error('--result 与 --cases 只适用于 --manual 人工记录。');
  if (options.result !== null && !['pass', 'fail', 'blocked'].includes(options.result)) {
    throw new Error('--result 只接受 pass、fail 或 blocked。');
  }
  if (options.stage !== null && options.stage !== 'candidate' && options.stage !== 'final') {
    throw new Error('--stage 只接受 candidate 或 final。');
  }
  return options;
}

/**
 * 在流程内执行项目 E2E 并写机器记录。
 * 退出码：0 通过、1 E2E 失败（记录已保存）、2 无法执行（缺命令、缺变更、参数不完整或已达重试上限）。
 */
async function runE2ERun(args, projectRoot = process.cwd()) {
  const options = parseE2ERunArguments(args);
  const planningRoot = options.planningRoot === null ? null : path.resolve(process.cwd(), options.planningRoot);
  const settings = resolveE2EConfig({ projectRoot: planningRoot ?? projectRoot });
  for (const error of settings.errors) process.stderr.write(`openspec-agentic: 错误: ${error}\n`);
  const result = await executeE2E({
    projectRoot,
    packageRoot,
    changeName: options.change,
    command: options.command,
    manual: options.manual,
    executor: options.executor,
    evidence: options.evidence,
    notes: options.notes,
    stage: options.stage,
    settings,
    planningRoot,
    result: options.result,
    cases: options.cases,
  });
  if (options.json) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  } else if (result.status === 'blocked') {
    process.stdout.write(`E2E run: BLOCKED — ${result.reason}\n`);
  } else {
    const relative = result.recordPath === undefined ? '' : `，记录 ${path.relative(projectRoot, result.recordPath).split(path.sep).join('/')}`;
    process.stdout.write(`E2E run: ${result.status === 'pass' ? 'PASS' : 'FAIL'}（${result.record.kind === 'manual' ? '人工记录' : `命令 ${result.record.command}`}${relative}）\n`);
  }
  process.exitCode = result.status === 'pass' ? 0 : (result.status === 'fail' ? 1 : 2);
}

/** 诊断：工具链、项目本地引擎版本、schema、配置、角色、验收 skill 与受管文件漂移。 */
export async function doctor(targetPath = process.cwd()) {
  const metadata = await loadPackageMetadata(packageRoot);
  const checks = [];
  const record = (label, status, detail) => checks.push({ label, status, detail });

  try {
    const toolchain = await assertToolchain(metadata.engines);
    record('toolchain', 'PASS', `Node ${toolchain.node} / npm ${toolchain.npm}`);
  } catch (error) {
    record('toolchain', 'FAIL', error.message);
  }

  const engineVersion = await projectEngineVersion(targetPath);
  if (engineVersion === metadata.enginePin) record('openspec', 'PASS', `项目本地 ${ENGINE_PACKAGE} ${engineVersion}`);
  else record('openspec', 'FAIL', `需要项目本地 ${ENGINE_PACKAGE} ${metadata.enginePin}，当前为 ${engineVersion ?? '未安装'}`);

  let configPath = null;
  try {
    configPath = projectConfigPath(targetPath);
  } catch (error) {
    record('config', 'FAIL', error.message);
  }
  if (configPath === null && checks.every((check) => check.label !== 'config')) {
    record('config', 'FAIL', '未找到 openspec/config.yaml');
  } else if (configPath !== null) {
    let rawConfig;
    try {
      rawConfig = YAML.parse(await fs.readFile(configPath, 'utf8')) ?? {};
    } catch (error) {
      record('config', 'FAIL', `无法解析 ${configPath}：${error.message}`);
      rawConfig = null;
    }
    if (rawConfig !== null) {
      const resolved = resolveRoleModels({ projectRoot: targetPath });
      const e2e = resolveE2EConfig({ projectRoot: targetPath });
      const configErrors = [...resolved.errors, ...e2e.errors];
      if (rawConfig.schema !== 'agentic') configErrors.push('openspec/config.yaml 的 schema 必须为 agentic');
      if (rawConfig['x-agentic']?.configVersion !== 1) configErrors.push('openspec/config.yaml 的 x-agentic.configVersion 必须为 1');
      if (configErrors.length > 0) record('config', 'FAIL', configErrors.join('；'));
      else record('config', 'PASS', `${resolved.configPath}，${resolved.configuredRoles} 个角色已配置；x-agentic.e2e.enabled=${e2e.enabled}`);
    }
  }

  if (await exists(path.join(targetPath, ...SCHEMA_RELATIVE_PATH.split('/'), 'schema.yaml'))) {
    record('schema', 'PASS', SCHEMA_RELATIVE_PATH);
  } else record('schema', 'FAIL', `缺少 ${SCHEMA_RELATIVE_PATH}/schema.yaml`);

  if (engineVersion === metadata.enginePin) {
    const result = await runEngine({ targetPath, packageRoot, args: ['schema', 'validate', 'agentic'], capture: true });
    const detail = `${result.stdout}${result.stderr}`.trim().split('\n').filter(Boolean).slice(-1)[0] ?? '';
    record('schema validation', result.status === 0 ? 'PASS' : 'FAIL', result.status === 0 ? 'openspec schema validate agentic' : detail);
  } else record('schema validation', 'BLOCKED', '项目本地引擎版本不符，未执行校验');

  if (await exists(path.join(targetPath, ...SKILL_RELATIVE_PATH.split('/'), 'SKILL.md'))) {
    record('verification skill', 'PASS', SKILL_RELATIVE_PATH);
  } else record('verification skill', 'FAIL', `缺少 ${SKILL_RELATIVE_PATH}/SKILL.md`);

  const agents = path.join(targetPath, 'AGENTS.md');
  const agentsText = await fs.readFile(agents, 'utf8').catch(() => '');
  record('AGENTS.md', agentsText.includes(AGENTIC_HEADING) ? 'PASS' : 'FAIL', 'agentic 验收路由');

  const manifest = await readManifest(targetPath);
  if (manifest === null) record('manifest', 'FAIL', `缺少 ${MANIFEST_RELATIVE_PATH}（先运行 init 或 update）`);
  else {
    const drift = await diffManagedFiles(targetPath, manifest);
    const changed = [...drift.modified, ...drift.missing, ...drift.added];
    if (manifest.agenticVersion !== metadata.version) {
      changed.push('manifest.agenticVersion');
    }
    const unmanaged = drift.unmanagedRoots.length > 0 ? `；未受管（未纳入校验）：${drift.unmanagedRoots.join('、')}` : '';
    record('manifest', changed.length === 0 ? 'PASS' : 'FAIL',
      changed.length === 0
        ? `agentic ${manifest.agenticVersion} / openspec ${manifest.openspecVersion}${unmanaged}`
        : `受管文件与清单不一致：${changed.slice(0, 5).join('、')}${changed.length > 5 ? '…' : ''}（--force 可覆盖，手工修改会被保留）`);
  }

  for (const check of checks) process.stdout.write(`${check.status}  ${check.label}: ${check.detail}\n`);
  const failed = checks.filter((check) => check.status !== 'PASS');
  process.stdout.write(`Installation: ${failed.length === 0 ? 'PASS' : 'FAIL'}\n`);
  return failed.length === 0;
}

export async function run(args) {
  const [command, ...commandArgs] = args;
  if (!command || command === '--help' || command === '-h') { process.stdout.write(help); return; }
  if (command === '--version' || command === '-V') {
    const metadata = await loadPackageMetadata(packageRoot);
    process.stdout.write(`${metadata.version}\n`);
    return;
  }
  if (command === 'roles') { runRoles(commandArgs); return; }
  if (command === 'workflow') {
    if (commandArgs[0] !== 'check') throw new Error('workflow 只支持 check');
    const options = { changeName: null, stage: 'plan', planningRoot: null };
    let json = false;
    const fields = { '--change': 'changeName', '--stage': 'stage', '--planning-root': 'planningRoot' };
    for (let index = 1; index < commandArgs.length; index += 1) {
      const arg = commandArgs[index];
      if (arg === '--json') { json = true; continue; }
      if (!fields[arg] || !commandArgs[index + 1] || commandArgs[index + 1].startsWith('--')) throw new Error(`无效 workflow 参数：${arg}`);
      options[fields[arg]] = commandArgs[++index];
    }
    if (!options.changeName || !['plan', 'final', 'archive'].includes(options.stage)) throw new Error('需要 --change；--stage 只接受 plan、final、archive');
    if (options.planningRoot) options.planningRoot = path.resolve(options.planningRoot);
    const result = await checkWorkflow({ projectRoot: process.cwd(), packageRoot, ...options });
    process.stdout.write(json ? `${JSON.stringify(result, null, 2)}\n` : `Workflow check: ${result.result}\n${JSON.stringify(result, null, 2)}\n`);
    if (result.result !== 'PASS') process.exitCode = result.result === 'BLOCKED' ? 2 : 1;
    return;
  }
  if (command === 'e2e') {
    const [action, ...actionArgs] = commandArgs;
    if (action === 'check') await runE2ECheck(actionArgs);
    else if (action === 'run') await runE2ERun(actionArgs);
    else runE2E(commandArgs);
    return;
  }
  if (command === 'init' || command === 'update') { await runInstallCommand(command, commandArgs); return; }
  if (command === 'doctor') {
    const { target } = parseOptions(commandArgs);
    if (!await doctor(path.resolve(process.cwd(), target))) process.exitCode = 1;
    return;
  }
  throw new Error(`Unknown command "${command}".\n\n${help}`);
}
