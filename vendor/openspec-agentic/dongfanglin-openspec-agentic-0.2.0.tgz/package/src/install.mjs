import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import YAML from 'yaml';
import { AGENTIC_SECTION, CONFIG_VERSION, defaultRoleModels, resolveRoleModels, setConfigValue } from './roles.mjs';
import { E2E_DEFAULTS, resolveE2EConfig } from './e2e.mjs';
import {
  MANIFEST_RELATIVE_PATH, SCHEMA_RELATIVE_PATH, SKILL_RELATIVE_PATH, diffManagedTree, managedRootFiles,
  readManifest, writeManifest,
} from './manifest.mjs';
import {
  AGENTIC_HEADING, ENGINE_PACKAGE, assertToolchain, ensurePackageJson, exists, installDependencies,
  loadPackageMetadata, projectEngineVersion, projectPackageVersion, readPackageJson, recordDevDependencies, runEngine,
} from './project.mjs';
import { adjudicateLegacy, backupLegacyConfig, detectInstallState, LEGACY_BACKUP_SUFFIX, openspecConfigPath, readLegacyConfig, readOpenspecValues } from './migrate.mjs';

/**
 * 安装与升级：一条命令完成引擎初始化、agentic schema、项目配置、角色模型、验收 skill、
 * AGENTS.md 指引和安装清单，任一步失败即回滚本次写入。
 */

const SCHEMA_SOURCE = ['assets', 'openspec', 'schemas', 'agentic'];
const CONFIG_FRAGMENT = ['assets', 'openspec', 'config.yaml'];
const SKILL_SOURCE = ['.agents', 'skills', 'agentic-verify'];
const AGENTS_FRAGMENT = ['AGENTS.md'];
const CONFIG_RELATIVE_PATHS = ['openspec/config.yaml', 'openspec/config.yml'];

/** 回滚范围：扩展写入或合并的全部路径。 */
const MANAGED_RELATIVE_PATHS = [
  ...CONFIG_RELATIVE_PATHS,
  SCHEMA_RELATIVE_PATH,
  MANIFEST_RELATIVE_PATH,
  SKILL_RELATIVE_PATH,
  'AGENTS.md',
  'package.json',
  'package-lock.json',
];

/**
 * 引擎按 --tools 会把生成物写进既有宿主目录（`.claude`、`.codex` 等），并且会就地刷新其中已存在的文件，
 * 因此这些目录按内容整体备份；版本库与常见缓存目录排除在外，避免备份无关的大目录。
 */
const HOST_DIR_EXCLUSIONS = new Set([
  '.git', '.hg', '.svn', '.tmp', '.cache', '.venv', 'venv', '.next', '.turbo', '.parcel-cache', '.gradle',
]);

/** 顶层文件体积上限：引擎只改写小型配置文件，超过该值不参与备份，避免复制大文件。 */
const HOST_FILE_LIMIT = 8 * 1024 * 1024;

/**
 * 本次运行的写入范围快照。失败时只还原本次真正写入过的路径，并删除本次新建的条目。
 * 记录的是「本次确实写过什么」而不是「可能会写什么」：零写入的失败不做任何还原，
 * 避免在没有必要时对用户目录做 rm + cp。
 * 备份失败的受管路径不被改写（宁可停止）；宿主路径备份失败只记录并继续，
 * 因为这些路径里的生成物由引擎维护，重新运行即可重建。
 */
class InstallTransaction {
  constructor(targetPath) {
    this.targetPath = targetPath;
    this.topLevel = new Set();
    this.snapshots = [];
    this.created = [];
    this.createdDirs = new Set();
    this.touched = new Set();
    this.hostTouched = false;
    this.unbackedHosts = [];
    this.backupDir = null;
  }

  async begin(extraRelativePaths = []) {
    const entries = await fs.readdir(this.targetPath, { withFileTypes: true }).catch(() => []);
    this.topLevel = new Set(entries.map((entry) => entry.name));
    const tracked = [...MANAGED_RELATIVE_PATHS, ...extraRelativePaths];
    for (const relative of tracked) {
      // 记录本次运行会新建的父目录，回滚后一并清理，避免留下空目录。
      const parts = relative.split('/');
      for (let depth = 1; depth < parts.length; depth += 1) {
        const ancestor = parts.slice(0, depth).join('/');
        if (!(await exists(path.join(this.targetPath, ...ancestor.split('/'))))) this.createdDirs.add(ancestor);
      }
    }
    const candidates = tracked.map((relative) => ({ backupKey: relative, relative, tracked: true, host: false }));
    const byRelative = new Map(candidates.map((candidate) => [candidate.relative, candidate]));
    for (const entry of entries) {
      if (entry.isDirectory()) {
        if (!entry.name.startsWith('.') || HOST_DIR_EXCLUSIONS.has(entry.name)) continue;
        const existing = byRelative.get(entry.name);
        if (existing) existing.host = true;
        else candidates.push({ backupKey: path.join('__host__', entry.name), relative: entry.name, tracked: false, host: true });
        continue;
      }
      if (!entry.isFile()) continue;
      // 引擎的旧版清理会就地改写项目根的配置文件（AGENTS.md、CLAUDE.md 等），因此顶层文件也纳入快照。
      const existing = byRelative.get(entry.name);
      if (existing) existing.host = true;
      else candidates.push({ backupKey: path.join('__host__', entry.name), relative: entry.name, tracked: false, host: true });
    }

    this.backupDir = await fs.mkdtemp(path.join(os.tmpdir(), 'openspec-agentic-backup-'));
    try {
      for (const candidate of candidates) {
        const { backupKey, relative, tracked: isTracked, host } = candidate;
        const source = path.join(this.targetPath, ...relative.split('/'));
        if (!(await exists(source))) {
          if (isTracked) this.created.push(relative);
          continue;
        }
        if (host && !isTracked && !(await isWithinSizeLimit(source))) {
          this.unbackedHosts.push(`${relative}：文件超过 ${HOST_FILE_LIMIT / 1024 / 1024} MiB`);
          continue;
        }
        try {
          await fs.cp(source, path.join(this.backupDir, ...backupKey.split(/[\\/]/)), { recursive: true });
          this.snapshots.push({ backupKey, relative, tracked: isTracked, host });
        } catch (error) {
          if (host && !isTracked) {
            this.unbackedHosts.push(`${relative}：${error.message}`);
            continue;
          }
          // 受管路径备份不完整就不能保证回滚，宁可停止也不要在没有退路的情况下改写用户文件。
          throw new Error(`无法备份 ${relative}（${error.message}）；请检查该路径的权限或符号链接后重试。`);
        }
      }
    } catch (error) {
      await fs.rm(this.backupDir, { recursive: true, force: true }).catch(() => {});
      this.backupDir = null;
      throw error;
    }
  }

  /** 每次真正写入前登记；未登记的路径不会在回滚时被还原。 */
  touch(...relativePaths) {
    for (const relative of relativePaths) this.touched.add(relative);
  }

  /** 引擎按 --tools 写入未知宿主路径（含项目根配置文件）时调用：回滚按快照整体还原这些路径。 */
  touchHostPaths() {
    this.hostTouched = true;
  }

  /** 还原本次写入过的路径，删除本次新建的受管路径与顶层条目，并清理新建的空父目录。 */
  async rollback() {
    if (this.backupDir === null) return { restored: 0, removed: 0, failed: [], backupDir: null };
    const backupDir = this.backupDir;
    this.backupDir = null;
    const failed = [];
    if (this.touched.size === 0 && !this.hostTouched) {
      await fs.rm(backupDir, { recursive: true, force: true }).catch(() => {});
      return { restored: 0, removed: 0, failed, backupDir: null };
    }
    let restored = 0;
    let removed = 0;
    for (const entry of await fs.readdir(this.targetPath).catch(() => [])) {
      if (this.topLevel.has(entry) || entry === 'node_modules') continue;
      try {
        await fs.rm(path.join(this.targetPath, entry), { recursive: true, force: true });
        removed += 1;
      } catch (error) {
        failed.push(`${entry}：${error.message}`);
      }
    }
    for (const relative of this.created) {
      if (!this.touched.has(relative)) continue;
      const target = path.join(this.targetPath, ...relative.split('/'));
      // force rm 对不存在的路径是 no-op；只有真正删掉了才计入报告。
      if (!(await exists(target))) continue;
      try {
        await fs.rm(target, { recursive: true, force: true });
        removed += 1;
      } catch (error) {
        failed.push(`${relative}：${error.message}`);
      }
    }
    for (const { backupKey, relative, tracked: isTracked, host } of this.snapshots) {
      const needsRestore = (isTracked && this.touched.has(relative)) || (host && this.hostTouched);
      if (!needsRestore) continue;
      const target = path.join(this.targetPath, ...relative.split('/'));
      try {
        await fs.rm(target, { recursive: true, force: true });
        await fs.cp(path.join(backupDir, ...backupKey.split(/[\\/]/)), target, { recursive: true });
        restored += 1;
      } catch (error) {
        failed.push(`${relative}：${error.message}`);
      }
    }
    for (const ancestor of [...this.createdDirs].sort((left, right) => right.length - left.length)) {
      await fs.rmdir(path.join(this.targetPath, ...ancestor.split('/'))).catch(() => {});
    }
    if (failed.length > 0) return { restored, removed, failed, backupDir };
    await fs.rm(backupDir, { recursive: true, force: true }).catch(() => {});
    return { restored, removed, failed, backupDir: null };
  }

  async commit() {
    if (this.backupDir === null) return;
    await fs.rm(this.backupDir, { recursive: true, force: true });
    this.backupDir = null;
  }
}

async function isWithinSizeLimit(filePath) {
  try {
    return (await fs.stat(filePath)).size <= HOST_FILE_LIMIT;
  } catch {
    return false;
  }
}

/**
 * 受管目录安装。判定顺序以"清单里是否记录过这个根目录"为准：
 * - 有记录且有漂移 → 保留本地修改（--force 可覆盖）；
 * - 无记录（未受管）→ 保留，且不写入基线，避免下一次直接被覆盖；
 * - 有记录且无漂移 → 刷新；无记录 → 保留，除非显式 --force；
 * - --force → 一律用包内版本替换。
 */
async function installOwnedTree({ targetPath, source, relativePath, label, force, dryRun, manifest, messages, touch }) {
  const destination = path.join(targetPath, ...relativePath.split('/'));
  const destinationExists = await exists(destination);
  if (destinationExists && !force) {
    const drift = manifest === null ? null : await diffManagedTree(targetPath, manifest, relativePath);
    if (drift !== null && drift.modified.length + drift.missing.length + drift.added.length > 0) {
      messages.push(`Kept locally modified ${label}: ${relativePath}（--force 可覆盖）`);
      return 'kept-modified';
    }
    if (drift === null) {
      messages.push(`Kept unmanaged ${label}: ${relativePath}（--force 可覆盖）`);
      return 'kept-unmanaged';
    }
  }
  if (dryRun) {
    messages.push(`Would ${destinationExists ? 'replace' : 'install'} ${label}: ${relativePath}`);
    return destinationExists ? 'replaced' : 'installed';
  }
  // 先写暂存目录再改名：窗口内中断也不会留下被删除一半的受管目录。
  // 暂存名带随机后缀，避免删掉用户同名目录。
  touch(relativePath);
  const staging = path.join(path.dirname(destination), `.agentic-staging-${process.pid.toString(36)}-${Date.now().toString(36)}`);
  await fs.cp(source, staging, { recursive: true });
  if (destinationExists) await fs.rm(destination, { recursive: true, force: true });
  try {
    await fs.rename(staging, destination);
  } catch (error) {
    await fs.rm(staging, { recursive: true, force: true }).catch(() => {});
    throw error;
  }
  messages.push(`${destinationExists ? 'Replaced' : 'Installed'} ${label}: ${relativePath}`);
  return destinationExists ? 'replaced' : 'installed';
}

/** 项目本地依赖：已按固定版本就位的项目不重复安装，离线与 CI 也能通过。 */
async function ensureDependencies({ targetPath, metadata, dryRun, noInstall, allowMissingNoInstall = false, messages, touch }) {
  const targetMetadata = await readPackageJson(targetPath);
  const selfHosted = targetMetadata.name === metadata.name;
  const engineVersion = await projectEngineVersion(targetPath);
  const engineReady = engineVersion === metadata.enginePin;
  const selfVersion = selfHosted ? metadata.version : await projectPackageVersion(targetPath, metadata.name);
  const selfReady = selfHosted || selfVersion === metadata.version;

  const specs = [];
  if (!engineReady) specs.push(`${ENGINE_PACKAGE}@${metadata.enginePin}`);
  if (!selfReady) specs.push(`${metadata.name}@${metadata.version}`);

  if (specs.length === 0) messages.push(`Kept project-local dependencies (${ENGINE_PACKAGE} ${engineVersion})`);
  else if (noInstall) {
      if (!dryRun && !engineReady && !allowMissingNoInstall) {
      throw new Error(`--no-install 要求项目本地已安装 ${ENGINE_PACKAGE}@${metadata.enginePin}；当前未找到匹配版本。请先运行 npm install，或去掉 --no-install。`);
    }
    messages.push(`Skipped project-local dependency installation (--no-install): ${specs.join(', ')}`);
  }
  else if (dryRun) messages.push(`Would install project-local dependencies: ${specs.join(', ')}`);
  else {
    messages.push(`Installing project-local dependencies: ${specs.join(', ')}`);
    touch('package.json', 'package-lock.json');
    installDependencies(targetPath, specs);
  }

  // 记录规范化版本；自举场景保留 npm 写入的本地引用，不把包自身指向 registry。
  const recorded = { [ENGINE_PACKAGE]: metadata.enginePin };
  if (!selfHosted) recorded[metadata.name] = metadata.version;
  if (!dryRun) {
    const changed = await recordDevDependencies(targetPath, recorded);
    if (changed) touch('package.json');
  }

  return { engineVersion: engineVersion ?? metadata.enginePin, selfHosted };
}

/** `x-agentic.roles` 的键值对节点；不存在时返回 undefined。 */
function rolesPairOf(document) {
  const section = document.getIn([AGENTIC_SECTION], true);
  if (!section || typeof section.items === 'undefined') return undefined;
  return section.items.find((item) => String(item.key?.value ?? item.key) === 'roles');
}

/** `roles` 段里各角色的行尾注释；键为角色 ID。 */
function roleCommentsOf(document) {
  const roles = document.getIn([AGENTIC_SECTION, 'roles'], true);
  const comments = new Map();
  if (!roles || typeof roles.items === 'undefined') return comments;
  for (const pair of roles.items) {
    const id = String(pair.key?.value ?? pair.key);
    const comment = typeof pair.value?.comment === 'string' ? pair.value.comment : undefined;
    if (comment !== undefined) comments.set(id, comment);
  }
  return comments;
}

/** 段落级注释：旧版把建议写在 `roles:` 上方，存在时不再逐角色重复建议。 */
function keyComment(pair) {
  const key = pair?.key;
  return key !== null && typeof key === 'object' ? key.commentBefore : undefined;
}

/** x-agentic.e2e 的行尾说明；只在缺失时补，不覆盖用户自写注释（前置空格与 yaml 解析出的注释一致）。 */
const E2E_COMMENTS = {
  enabled: ' 项目级 E2E 校验开关：true 时每次变更的 Main E2E mode 必须为 required，降级需用户显式批准',
  command: ' 项目真实 E2E 命令或入口；可留空，执行时按计划确定',
  maxAttempts: ' 同一变更连续失败的 E2E 重试上限；达到后停止自动重跑，须用户介入（默认 3）',
};

/** 项目级 E2E 开关：只补缺失键，默认开启；用户显式写下的值保持不动。 */
function seedE2ESettings(document, notes) {
  const section = document.getIn([AGENTIC_SECTION], true);
  if (section === null || typeof section !== 'object' || typeof section.items === 'undefined') return;
  let node = document.getIn([AGENTIC_SECTION, 'e2e'], true);
  if (node === null || typeof node !== 'object' || typeof node.items === 'undefined') {
    node = document.createNode({ ...E2E_DEFAULTS });
    section.set(document.createNode('e2e'), node);
    notes.push(`seeded ${AGENTIC_SECTION}.e2e (enabled: ${E2E_DEFAULTS.enabled})`);
  } else if (node.flow !== undefined) {
    node.flow = false;
  }
  for (const [key, value] of Object.entries(E2E_DEFAULTS)) {
    if (!node.has(key)) {
      node.set(key, value);
      notes.push(`seeded ${AGENTIC_SECTION}.e2e.${key}`);
    }
    const valueNode = node.get(key, true);
    if (valueNode !== null && typeof valueNode === 'object'
      && typeof valueNode.comment !== 'string' && E2E_COMMENTS[key] !== undefined) {
      valueNode.comment = E2E_COMMENTS[key];
    }
  }
}

/** 项目配置：只补缺失项，保留用户已写内容；schema 固定为 agentic。 */
async function mergeProjectConfig({ targetPath, packageRoot, dryRun, messages, seedRoles, adopt, touch }) {
  // 引擎与解析侧都接受 config.yaml 与 config.yml；必须写回解析到的那个文件，避免生成第二份配置。
  const configPath = openspecConfigPath(targetPath) ?? path.join(targetPath, 'openspec', 'config.yaml');
  const configRelative = path.relative(targetPath, configPath).split(path.sep).join('/');
  const fragmentText = await fs.readFile(path.join(packageRoot, ...CONFIG_FRAGMENT), 'utf8');
  const fragmentDocument = YAML.parseDocument(fragmentText, { lineWidth: 0 });
  const fragment = fragmentDocument.toJS() ?? {};
  const targetExists = await exists(configPath);
  let document;
  if (targetExists) {
    document = YAML.parseDocument(await fs.readFile(configPath, 'utf8'), { lineWidth: 0 });
    if (document.errors.length > 0) throw new Error(`${configPath} 不是合法 YAML：${document.errors[0].message}`);
    if (document.contents === null) document.contents = document.createNode({});
  } else {
    document = YAML.parseDocument('{}\n');
  }
  if (document.contents?.flow) document.contents.flow = false;

  mergeMissingFields(document, fragment, document.toJS() ?? {});
  document.set('schema', 'agentic');
  if (!document.hasIn([AGENTIC_SECTION, 'configVersion'])) {
    setConfigValue(document, [AGENTIC_SECTION, 'configVersion'], CONFIG_VERSION);
  }

  const notes = [];
  for (const [id, model] of Object.entries(adopt?.roles ?? {})) {
    setConfigValue(document, [AGENTIC_SECTION, 'roles', id], model);
    notes.push(`migrated ${AGENTIC_SECTION}.roles.${id}`);
  }
  if (adopt?.context !== undefined) {
    document.set('context', document.createNode(adopt.context, { type: 'BLOCK_LITERAL' }));
    notes.push('migrated context');
  }
  for (const [operation, settings] of Object.entries(adopt?.operations ?? {})) {
    for (const [field, value] of Object.entries(settings)) {
      setConfigValue(document, ['operations', operation, field], value);
      notes.push(`migrated operations.${operation}.${field}`);
    }
  }
  const advice = roleCommentsOf(fragmentDocument);

  if (seedRoles) {
    if (!document.hasIn([AGENTIC_SECTION, 'roles'])) {
      const section = document.getIn([AGENTIC_SECTION], true);
      section.set(document.createNode('roles'), document.createNode(defaultRoleModels()));
      notes.push(`seeded ${AGENTIC_SECTION}.roles`);
    }
    for (const [id, model] of Object.entries(defaultRoleModels())) {
      if (!document.hasIn([AGENTIC_SECTION, 'roles', id])) {
        setConfigValue(document, [AGENTIC_SECTION, 'roles', id], model);
        notes.push(`seeded ${AGENTIC_SECTION}.roles.${id}`);
      }
    }
  }

  seedE2ESettings(document, notes);

  // 逐角色补上档位建议：只补没有行尾注释的角色；用户已写注释不覆盖，
  // 旧版把建议写在 `roles:` 上方时也不再逐角色重复。
  const rolesPair = rolesPairOf(document);
  const rolesNode = document.getIn([AGENTIC_SECTION, 'roles'], true);
  let annotated = 0;
  if (keyComment(rolesPair) === undefined && rolesNode !== null && typeof rolesNode === 'object'
    && typeof rolesNode.items !== 'undefined') {
    for (const pair of rolesNode.items) {
      const id = String(pair.key?.value ?? pair.key);
      const comment = advice.get(id);
      const value = pair.value;
      if (comment === undefined || value === null || typeof value !== 'object') continue;
      if (typeof value.comment === 'string') continue;
      value.comment = comment;
      annotated += 1;
    }
  }
  if (annotated > 0) notes.push(`annotated ${annotated} role(s) with tier guidance`);

  const rolesNode2 = document.getIn([AGENTIC_SECTION, 'roles'], true);
  if (rolesNode2?.flow !== undefined) rolesNode2.flow = false;
  const next = document.toString({ lineWidth: 0 });
  for (const note of notes) messages.push(`Config: ${note}`);
  const check = resolveRoleModels({ projectRoot: targetPath, configText: next });
  const writeErrors = [...check.errors, ...resolveE2EConfig({ projectRoot: targetPath, configText: next }).errors];
  if (writeErrors.length > 0) throw new Error(`无法写入 ${configPath}：${writeErrors.join('；')}`);
  if (targetExists && next === await fs.readFile(configPath, 'utf8')) {
    if (notes.length === 0) messages.push(`Kept project config: ${configRelative}`);
    return { roles: check.configuredRoles, notes };
  }
  if (dryRun) {
    messages.push(`Would ${targetExists ? 'merge' : 'create'} project config: ${configRelative}`);
    return { roles: check.configuredRoles, notes };
  }
  await fs.mkdir(path.dirname(configPath), { recursive: true });
  touch(configRelative);
  await fs.writeFile(configPath, next, 'utf8');
  messages.push(`${targetExists ? 'Merged' : 'Created'} project config: ${configRelative}`);
  return { roles: check.configuredRoles, notes };
}

/** 递归补缺：只写入目标缺失的键，不覆盖已有值，也不合并数组。 */
function mergeMissingFields(document, defaults, current, pathParts = []) {
  let changed = false;
  for (const [key, value] of Object.entries(defaults)) {
    if (pathParts.length === 0 && (key === 'schema' || key === AGENTIC_SECTION)) continue;
    if (pathParts[0] === AGENTIC_SECTION && key === 'roles') continue;
    const nextPath = [...pathParts, key];
    if (!Object.hasOwn(current, key)) {
      setConfigValue(document, nextPath, value);
      changed = true;
    } else if (typeof value === 'object' && value !== null && !Array.isArray(value)
      && typeof current[key] === 'object' && current[key] !== null && !Array.isArray(current[key])) {
      changed = mergeMissingFields(document, value, current[key], nextPath) || changed;
    }
  }
  return changed;
}

/** AGENTS.md：缺失即安装，已有 agentic 段落则保留用户版本。 */
async function installAgentsInstructions({ targetPath, packageRoot, dryRun, messages, touch }) {
  const fragment = await fs.readFile(path.join(packageRoot, ...AGENTS_FRAGMENT), 'utf8');
  const destination = path.join(targetPath, 'AGENTS.md');
  if (!(await exists(destination))) {
    if (!dryRun) {
      touch('AGENTS.md');
      await fs.writeFile(destination, fragment, 'utf8');
    }
    messages.push(`${dryRun ? 'Would install' : 'Installed'} AGENTS.md workflow instructions`);
    return 'installed';
  }
  const current = await fs.readFile(destination, 'utf8');
  if (current.includes(AGENTIC_HEADING)) {
    messages.push('Kept existing AGENTS.md agentic workflow instructions');
    return 'kept';
  }
  if (!dryRun) {
    touch('AGENTS.md');
    await fs.appendFile(destination, `\n\n${fragment}`, 'utf8');
  }
  messages.push(`${dryRun ? 'Would append' : 'Appended'} agentic workflow instructions to AGENTS.md`);
  return 'appended';
}

/** 安装后校验：由项目本地引擎校验 schema 结构与 artifact 模板。 */
async function validateInstallation({ targetPath, packageRoot, messages }) {
  const result = await runEngine({ targetPath, packageRoot, args: ['schema', 'validate', 'agentic'], capture: true });
  if (result.status === 0) {
    messages.push('Schema validation: PASS');
    return 'PASS';
  }
  messages.push('Schema validation: FAIL');
  const detail = `${result.stdout}${result.stderr}`.trim();
  if (detail) messages.push(detail.split('\n').slice(-5).join('\n'));
  return 'FAIL';
}

async function planMigration({ targetPath, prefer, messages }) {
  const state = detectInstallState(targetPath);
  if (state.legacy.configPath === null) {
    // 无旧配置时，旧 schema 目录属于纯旧版项目；按受管目录处理，不做配置迁移。
    return null;
  }
  const legacy = await readLegacyConfig(state.legacy.configPath);
  const current = await readOpenspecValues(state.configPath);
  const decision = adjudicateLegacy({ legacy, current, prefer });
  if (decision.conflicts.length > 0) messages.push(`Resolved ${decision.conflicts.length} legacy conflict(s) with --prefer ${decision.prefer}`);
  return { ...decision, configPath: state.legacy.configPath, relative: state.legacy.configRelative };
}

function buildManifest({ metadata, engineVersion, previous, migration }) {
  const now = new Date().toISOString();
  // 迁移来源在后续 update 中也要保留：迁移只发生一次，但它仍是清单的可审计字段。
  const migratedFrom = migration?.relative ?? previous?.migratedFrom;
  return {
    agenticVersion: metadata.version,
    openspecVersion: engineVersion,
    configVersion: CONFIG_VERSION,
    schema: 'agentic',
    installedAt: previous?.installedAt ?? now,
    updatedAt: now,
    ...(migratedFrom === undefined ? {} : { migratedFrom }),
    files: {},
  };
}

/**
 * 只对本次真正写入的受管根目录刷新哈希；被保留的本地修改沿用原记录；未受管的根目录不写入基线。
 * 否则第二次 update 会把本地内容当作新基线，从而在未传 --force 时静默覆盖用户改动。
 */
async function collectManagedHashes({ targetPath, previousFiles, statuses }) {
  const files = {};
  for (const [root, status] of Object.entries(statuses)) {
    if (status === 'kept-unmanaged') continue;
    if (status === 'kept-modified') {
      for (const [name, hash] of Object.entries(previousFiles)) {
        if (name.startsWith(`${root}/`)) files[name] = hash;
      }
      continue;
    }
    Object.assign(files, await managedRootFiles(targetPath, root));
  }
  return files;
}

/**
 * init 与 update 共用同一条安装流程：安装写入范围事务化，失败回滚且不留下半安装状态。
 * init 播种七个默认角色；update 只迁移旧配置，保留用户对角色段的显式增删。
 */
export async function install({
  mode, targetPath, packageRoot, tools = 'none', prefer, force = false, dryRun = false, noInstall = false,
}) {
  const messages = [];
  const summary = {
    openspec: null,
    schema: 'pending',
    defaultSchema: 'agentic',
    roles: 0,
    skill: 'pending',
    schemaValidation: 'SKIPPED',
    installation: 'PASS',
  };
  const metadata = await loadPackageMetadata(packageRoot);
  const state = detectInstallState(targetPath);
  // 旧配置只决定是否进入迁移流程，不能作为覆盖既有 OpenSpec schema 的许可。
  const legacyDetected = state.legacy.configPath !== null;
  let createdRoot = false;
  if (mode === 'init' && legacyDetected) {
    throw new Error('检测到 fluentspec/ 旧配置；为避免覆盖旧项目配置，请改用 npx @dongfanglin/openspec-agentic@latest update . 执行迁移。');
  }
  if (!(await exists(targetPath))) {
    if (mode === 'update') throw new Error(`目标目录不存在：${targetPath}；请在项目根目录运行 npx @dongfanglin/openspec-agentic@latest init .`);
    if (!dryRun) {
      await fs.mkdir(targetPath, { recursive: true });
      createdRoot = true;
    }
  } else if (mode === 'update' && !state.openspecDir && !legacyDetected) {
    throw new Error('未找到 openspec/ 或 fluentspec/；新项目请先运行 npx @dongfanglin/openspec-agentic@latest init .');
  }

  const toolchain = await assertToolchain(metadata.engines);
  const transaction = new InstallTransaction(targetPath);
  let failure = null;
  const trackedExtras = state.legacy.configRelative === null
    ? []
    : [state.legacy.configRelative, `${state.legacy.configRelative}${LEGACY_BACKUP_SUFFIX}`];
  if (!dryRun) messages.push(`Toolchain: Node ${toolchain.node} / npm ${toolchain.npm}`);

  try {
    const touch = (...relativePaths) => transaction.touch(...relativePaths);
    if (!dryRun) await transaction.begin(trackedExtras);
    if (!dryRun && await ensurePackageJson(targetPath)) {
      touch('package.json');
      messages.push('Created package.json');
    }
    for (const unbacked of transaction.unbackedHosts) {
      messages.push(`无法备份宿主目录 ${unbacked}；回滚不会还原该目录（其中的生成物可由引擎重建）。`);
    }
    const dependencies = await ensureDependencies({ targetPath, metadata, dryRun, noInstall, allowMissingNoInstall: createdRoot, messages, touch });
    summary.openspec = dependencies.engineVersion;

    if (state.openspecDir) {
      messages.push('Kept existing openspec/');
    } else if (dryRun) {
      messages.push(`Would run OpenSpec init (--tools ${tools})`);
    } else {
      messages.push(`Running OpenSpec init (--tools ${tools})`);
      // 引擎会按 --tools 写入未知路径，并就地改写项目根配置文件：登记宿主路径快照。
      touch(...CONFIG_RELATIVE_PATHS);
      transaction.touchHostPaths();
      await runEngine({ targetPath, packageRoot, args: ['init', '.', '--tools', tools] });
    }

    const migration = mode === 'update' ? await planMigration({ targetPath, prefer, messages }) : null;
    const manifest = await readManifest(targetPath);

    summary.schema = await installOwnedTree({
      targetPath,
      source: path.join(packageRoot, ...SCHEMA_SOURCE),
      relativePath: SCHEMA_RELATIVE_PATH,
      label: 'agentic schema',
      force,
      dryRun,
      manifest,
      messages,
      touch,
    });
    const config = await mergeProjectConfig({
      targetPath,
      packageRoot,
      dryRun,
      messages,
      seedRoles: mode === 'init',
      adopt: migration?.adopt,
      touch,
    });
    summary.roles = config.roles;
    summary.skill = await installOwnedTree({
      targetPath,
      source: path.join(packageRoot, ...SKILL_SOURCE),
      relativePath: SKILL_RELATIVE_PATH,
      label: 'agentic-verify skill',
      force,
      dryRun,
      manifest,
      messages,
      touch,
    });
    await installAgentsInstructions({ targetPath, packageRoot, dryRun, messages, touch });

    if (!dryRun) {
      if (migration !== null) {
        // 改名会同时改动两个路径：原配置文件被移走，备份文件被创建。
        touch(migration.relative, `${migration.relative}${LEGACY_BACKUP_SUFFIX}`);
        const backup = await backupLegacyConfig(migration.configPath, { dryRun });
        messages.push(backup.status === 'renamed'
          ? `Backed up legacy config: ${path.relative(targetPath, backup.path).split(path.sep).join('/')}`
          : `Kept existing legacy backup: ${path.relative(targetPath, backup.path).split(path.sep).join('/')}`);
      }
      const next = buildManifest({ metadata, engineVersion: summary.openspec, previous: manifest, migration });
      next.files = await collectManagedHashes({
        targetPath,
        previousFiles: manifest?.files ?? {},
        statuses: { [SCHEMA_RELATIVE_PATH]: summary.schema, [SKILL_RELATIVE_PATH]: summary.skill },
      });
      touch(MANIFEST_RELATIVE_PATH);
      await writeManifest(targetPath, next);
      messages.push(`Wrote install manifest: ${MANIFEST_RELATIVE_PATH}`);
      summary.schemaValidation = await validateInstallation({ targetPath, packageRoot, messages });
      if (summary.schemaValidation !== 'PASS') throw new Error('安装后 schema 校验未通过。');
      await transaction.commit();
    }
  } catch (error) {
    failure = error;
    if (!dryRun) {
      const { restored, removed, failed, backupDir } = await transaction.rollback();
      const actions = [];
      if (restored > 0) actions.push(`restored ${restored}`);
      if (removed > 0) actions.push(`removed ${removed}`);
      messages.push(actions.length > 0
        ? `Rolled back every write from this run（${actions.join(', ')} path(s)）`
        : 'No write from this run required rollback.');
      if (failed.length > 0) {
        messages.push(`回滚未能恢复以下路径：${failed.join('；')}；未删除的备份位于 ${backupDir}`);
      }
      if (createdRoot) await fs.rmdir(targetPath).catch(() => {});
    }
    summary.installation = 'FAIL';
  }

  return { messages, summary, failure };
}
