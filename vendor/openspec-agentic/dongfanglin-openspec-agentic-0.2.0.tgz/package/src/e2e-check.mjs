import fs from 'node:fs/promises';
import path from 'node:path';
import { E2E_DEFAULTS, resolveE2EConfig } from './e2e.mjs';
import { consecutiveFailures, evaluateRecordFreshness, readE2ERecords, resolveChangeRoot, runE2E } from './e2e-run.mjs';
import { runEngine } from './project.mjs';
import { optionalContractDigest } from './workflow-contract.mjs';

/**
 * 变更级 E2E 一致性检查：比对项目开关、plan.md 的 Main E2E 判据，
 * 以及 required 变更是否留下机器生成的执行记录（openspec-agentic e2e run 写入）。
 * 不解析 verification.md 的散文内容，也不阻止归档——它只是可机器执行的结构检查。
 */

const MAIN_E2E_HEADING = /^#{3}\s+Main E2E\s*$/;
// Main E2E 区块的结束边界：下一个任意级标题即停，包括 plan 模板紧随其后的 h4 小节（如
// `#### E2E Ownership and Cases`）。只用 h1–h3 会继续扫到正文，使 yaml 中漏写的字段被后续同名行冒充。
const NEXT_HEADING = /^#{1,6}\s+\S/;
const FIELD_LINE = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$/;
const MODE_REQUIRED = 'required';
const MODE_NOT_APPLICABLE = 'not-applicable';
const REQUIRED_NOT_APPLICABLE_FIELDS = ['reason', 'basis', 'alternative_checks'];
// 最终 E2E 任务行的机器所有者标记：带该标记的复选框由 e2e check 在证据 PASS 时回写，
// 主 Agent 不得手勾（行级单一所有者）。
const OWNED_TASK_MARKER = '[e2e-owned]';
// 最终验收任务标记：按 procedures/acceptance.md，验收期间该行必须保持待办，
// 因此它不算“其他未完成任务”，否则 E2E 完成条件与最终验收会互相死锁。
// 它只作定位用：与 OpenSpec“复选框即完成”的模型一致，不对该标记做存在性/唯一性机器校验。
const FINAL_VERIFICATION_MARKER = '[final-verification]';
// 块标量指示符：`key: |` / `key: >` 等多行写法；其后续缩进行属于该字段取值。
const BLOCK_INDICATORS = new Set(['|', '|-', '|+', '>', '>-', '>+']);
// [^\n] 而非 . ：保留 CRLF 行尾的 \r，回写时不破坏行尾。
const TASK_CHECKBOX = /^(\s*[-*]\s*\[)([ xX])(\]\s*)([^\n]*)$/;

/** 去掉行尾注释与包裹引号；引号内的 `#` 不作为注释起点。 */
function cleanValue(raw) {
  const text = String(raw);
  let quote = null;
  let end = text.length;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quote !== null) {
      if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || char === "'") {
      quote = char;
      continue;
    }
    if (char === '#') {
      end = index;
      break;
    }
  }
  let value = text.slice(0, end).trim();
  if (value.length >= 2 && ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'")))) {
    value = value.slice(1, -1).trim();
  }
  return value;
}

/** 列表值是否非空：`[]`、`[ ]`、`[""]` 视为空。 */
function hasEntries(value) {
  const text = String(value);
  if (text === '') return false;
  if (!text.startsWith('[')) return true;
  return text.replace(/^\[|\]$/g, '').replace(/[\s'"]/g, '').replace(/,/g, '').length > 0;
}

/**
 * 提取 `### Main E2E` 区块内声明的判据字段；同名字段取首次出现（yaml 块在注释之前）。
 * 支持行内标量与多行取值：块状序列（`alternative_checks:` 换行后的 `- x`）与块标量（`|` / `>`），
 * 避免合法的块状 YAML 列表被误判为空字段。
 * 找不到该标题时返回 null；字段缺失时为 undefined。
 */
export function parseMainE2EFields(planText) {
  const lines = String(planText).split(/\r?\n/);
  const start = lines.findIndex((line) => MAIN_E2E_HEADING.test(line));
  if (start === -1) return null;
  const fields = {};
  for (let index = start + 1; index < lines.length; index += 1) {
    const line = lines[index];
    if (NEXT_HEADING.test(line)) break;
    const match = FIELD_LINE.exec(line);
    if (match === null) continue;
    const key = match[1];
    if (Object.hasOwn(fields, key)) continue;
    const indent = line.match(/^\s*/)[0].length;
    let value = cleanValue(match[2]);
    if (value === '' || BLOCK_INDICATORS.has(value)) {
      // 收集比字段行更深的缩进内容；块状序列去掉 `- ` 前缀后以逗号连接，供 hasEntries 判非空。
      const collected = [];
      let cursor = index + 1;
      for (; cursor < lines.length; cursor += 1) {
        const raw = lines[cursor];
        if (raw.trim() === '') continue;
        if (NEXT_HEADING.test(raw)) break;
        if (raw.match(/^\s*/)[0].length <= indent) break;
        const item = raw.trim();
        collected.push(item.startsWith('- ') ? item.slice(2).trim() : item === '-' ? '' : item);
      }
      value = collected.join(', ');
      index = cursor - 1;
    }
    fields[key] = value;
  }
  return fields;
}

/** 引擎输出可能带前导说明文本；只取第一个 JSON 对象。 */
function parseJson(text) {
  const start = String(text).indexOf('{');
  if (start === -1) return null;
  try {
    return JSON.parse(String(text).slice(start));
  } catch {
    return null;
  }
}

const firstLine = (text) => String(text).trim().split('\n')[0] ?? '';

/**
 * 单个变更的判定：SKIPPED（非 agentic）不阻断；任务未完成时，查全部模式记为 IN_PROGRESS
 * 不参与判定，单变更模式（requireComplete）记为 BLOCKED——否则“完成条件 = check PASS”
 * 会在变更未完成时被平凡满足。
 *
 * 单变更模式下，有两类行允许保持待办，不视为“其他未完成任务”：
 *   - 带 [e2e-owned] 标记的最终 E2E 行（由扩展拥有，PASS 时回写）；
 *   - 带 [final-verification] 标记的最终验收行（验收期间按 acceptance.md 必须待办）。
 * 除此之外全部完成才继续判定证据，避免 E2E 完成条件与最终验收互相死锁。
 */
async function inspectChange({ name, complete, projectRoot, packageRoot, enabled, configuredCommand, maxAttempts = E2E_DEFAULTS.maxAttempts, requireComplete = false, preRun = null, planningRoot = null, write = true }) {
  const record = { name, complete, schema: null, mode: null, approval: false, result: 'PASS', reason: '' };
  const engineRoot = planningRoot ?? projectRoot;
  const status = await runEngine({ targetPath: engineRoot, packageRoot, args: ['status', '--change', name, '--json'], capture: true });
  const payload = status.status === 0 ? parseJson(status.stdout) : null;
  if (payload === null || typeof payload.changeRoot !== 'string' || typeof payload.schemaName !== 'string') {
    return { ...record, result: 'BLOCKED', reason: `引擎无法解析该变更（openspec status 退出码 ${status.status}）` };
  }
  record.schema = payload.schemaName;
  if (payload.schemaName !== 'agentic') {
    return { ...record, result: 'SKIPPED', reason: '非 agentic 变更，本检查不适用' };
  }

  // 行级单一所有者：只在单变更模式认领/回写最终 E2E 任务行；查全部模式只读。
  const owned = requireComplete ? await readOwnedE2ETask(payload.changeRoot) : null;
  if (owned !== null && owned.ambiguous) {
    return annotatePreRun({ ...record, result: 'BLOCKED', reason: `tasks.md 含多条 ${OWNED_TASK_MARKER} 标记；最终 E2E 任务必须唯一` }, preRun, projectRoot);
  }
  const ownedPending = owned !== null && owned.present && !owned.checked && owned.allOtherChecked;
  // PASS 时勾选扩展拥有的 E2E 行；非 PASS 且该行已被勾选时回退，避免证据失效后默认确认提示失效。
  const settle = async (verdict) => {
    if (owned !== null && owned.present) {
      const wouldWrite = (verdict.result === 'PASS' && ownedPending) || (verdict.result !== 'PASS' && owned.checked);
      if (!write && wouldWrite) {
        return annotatePreRun({ ...verdict, marked: false, reason: `${verdict.reason}；只读模式未回写 [e2e-owned] 任务行` }, preRun, projectRoot);
      }
      if (write && verdict.result === 'PASS' && ownedPending) {
        const marked = await markOwnedE2ETask(payload.changeRoot);
        if (marked) {
          return annotatePreRun({ ...verdict, marked: true, reason: `${verdict.reason}；已按 ${OWNED_TASK_MARKER} 勾选最终 E2E 任务` }, preRun, projectRoot);
        }
      } else if (write && verdict.result !== 'PASS' && owned.checked) {
        const reverted = await unmarkOwnedE2ETask(payload.changeRoot);
        if (reverted) {
          return annotatePreRun({ ...verdict, marked: false, reverted: true, reason: `${verdict.reason}；证据未通过，已回退 ${OWNED_TASK_MARKER} 任务行` }, preRun, projectRoot);
        }
      }
    }
    return annotatePreRun({ ...verdict, marked: false }, preRun, projectRoot);
  };

  if (!complete) {
    if (!requireComplete) {
      return settle({ ...record, result: 'IN_PROGRESS', reason: '任务未全部完成，尚未进入判定；完成后重新运行本检查' });
    }
    if (!(owned !== null && owned.allOtherChecked)) {
      return settle({ ...record, result: 'BLOCKED', reason: '任务未全部完成（除最终 E2E 行与最终验收行外仍有待办）；单变更检查要求变更完成后判定，未 PASS 即阻断' });
    }
    // 其余任务已完成，只差允许待办的行（扩展拥有的 E2E 行或正在执行的最终验收行）：继续判定。
  }

  let planText = null;
  try {
    planText = await fs.readFile(path.join(payload.changeRoot, 'plan.md'), 'utf8');
  } catch {
    planText = null;
  }
  if (planText === null) return settle({ ...record, result: 'BLOCKED', reason: '缺少 plan.md，无法判定 Main E2E 适用性' });

  const fields = parseMainE2EFields(planText);
  if (fields === null || fields.mode === undefined || fields.mode === '') {
    return settle({ ...record, result: 'BLOCKED', reason: 'plan.md 未声明 ### Main E2E 的 mode' });
  }
  const mode = fields.mode;
  record.mode = mode;
  if (mode !== MODE_REQUIRED && mode !== MODE_NOT_APPLICABLE) {
    return settle({ ...record, result: 'FAIL', reason: `mode 非法：${mode}（仅接受 required 或 not-applicable）` });
  }
  if (mode === MODE_REQUIRED) {
    const judged = await judgeRequiredRecord({
      record,
      changeRoot: payload.changeRoot,
      projectRoot,
      configuredCommand,
      maxAttempts,
    });
    return settle(judged);
  }

  record.approval = (fields.downgrade_approval ?? '').length > 0;
  const missing = REQUIRED_NOT_APPLICABLE_FIELDS.filter((key) => (key === 'alternative_checks' ? !hasEntries(fields[key] ?? '') : (fields[key] ?? '').length === 0));
  if (missing.length > 0) {
    return settle({ ...record, result: 'FAIL', reason: `not-applicable 缺少字段：${missing.join('、')}` });
  }
  if (enabled && !record.approval) {
    return settle({ ...record, result: 'FAIL', reason: 'x-agentic.e2e.enabled 为 true（或缺省）且 plan.md 未记录 downgrade_approval 批准，不得降级' });
  }
  const verdict = { ...record, result: 'PASS', reason: enabled ? 'not-applicable，批准字段非空（用户来源须独立核实）' : 'not-applicable，开关关闭且三字段齐备' };
  return settle(verdict);
}

/**
 * 定位 tasks.md 中带 [e2e-owned] 标记的最终 E2E 任务行：
 * 0 条 → present=false（旧变更，退回既有行为）；多条 → ambiguous（不猜，判 BLOCKED）。
 * allOtherChecked 表示除该行与 [final-verification] 行外其余复选框是否都已完成，
 * 用于区分“只差 E2E 证据 / 只差最终验收”与“还有别的活”。
 */
export async function readOwnedE2ETask(changeRoot) {
  let text;
  try {
    text = await fs.readFile(path.join(changeRoot, 'tasks.md'), 'utf8');
  } catch {
    return { present: false, ambiguous: false, checked: false, allOtherChecked: true };
  }
  const owned = [];
  let otherUnchecked = false;
  for (const line of text.split('\n')) {
    const match = TASK_CHECKBOX.exec(line);
    if (match === null) continue;
    const done = match[2].toLowerCase() === 'x';
    if (line.includes(OWNED_TASK_MARKER)) owned.push(done);
    else if (!done && !line.includes(FINAL_VERIFICATION_MARKER)) otherUnchecked = true;
  }
  if (owned.length === 0) return { present: false, ambiguous: false, checked: false, allOtherChecked: !otherUnchecked };
  if (owned.length > 1) return { present: true, ambiguous: true, checked: false, allOtherChecked: !otherUnchecked };
  return { present: true, ambiguous: false, checked: owned[0], allOtherChecked: !otherUnchecked };
}

/** 只把带 [e2e-owned] 标记的那一行翻成 [x]；幂等，保留其余行与行尾不变。 */
export async function markOwnedE2ETask(changeRoot) {
  const file = path.join(changeRoot, 'tasks.md');
  let text;
  try {
    text = await fs.readFile(file, 'utf8');
  } catch {
    return false;
  }
  const lines = text.split('\n');
  let changed = false;
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    if (!line.includes(OWNED_TASK_MARKER)) continue;
    const match = TASK_CHECKBOX.exec(line);
    if (match === null || match[2].toLowerCase() === 'x') continue;
    lines[index] = `${match[1]}x${match[3]}${match[4]}`;
    changed = true;
  }
  if (changed) await fs.writeFile(file, lines.join('\n'), 'utf8');
  return changed;
}

/** 把带 [e2e-owned] 标记的那一行回退为 [ ]；幂等，用于证据不再通过时让归档未完成任务门重新生效。 */
export async function unmarkOwnedE2ETask(changeRoot) {
  const file = path.join(changeRoot, 'tasks.md');
  let text;
  try {
    text = await fs.readFile(file, 'utf8');
  } catch {
    return false;
  }
  const lines = text.split('\n');
  let changed = false;
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    if (!line.includes(OWNED_TASK_MARKER)) continue;
    const match = TASK_CHECKBOX.exec(line);
    if (match === null || match[2].toLowerCase() !== 'x') continue;
    lines[index] = `${match[1]} ${match[3]}${match[4]}`;
    changed = true;
  }
  if (changed) await fs.writeFile(file, lines.join('\n'), 'utf8');
  return changed;
}

const bySeverity = (changes) => {
  if (changes.some((change) => change.result === 'FAIL')) return 'FAIL';
  if (changes.some((change) => change.result === 'BLOCKED')) return 'BLOCKED';
  return 'PASS';
};

/** 归一化命令字符串，用于比对记录命令与 x-agentic.e2e.command。 */
const normalizeCommand = (value) => String(value ?? '').trim();

/**
 * 判断现有记录是否已满足 required 的证据要求；needsRun 表示“重跑 E2E 有机会修复”，
 * 供 --run-if-missing 决定是否实际执行（broken 记录无法靠重跑消除，不在其列）。
 *
 * 收紧点：
 * - 候选阶段记录（stage: candidate）不满足最终 E2E 门；
 * - 配置了 x-agentic.e2e.command 时，相关成功记录必须由该命令自动执行；
 * - 最近一次相关尝试必须成功，更新的失败不能被更早的 pass 掩盖；
 * - 无法核对记录与当前目标版本（无 git/缺提交信息/无法比较）时判 BLOCKED，不允许“版本未核对”冒充有效。
 */
async function assessRequiredEvidence({ records, projectRoot, changeRoot, configuredCommand, maxAttempts = E2E_DEFAULTS.maxAttempts }) {
  const broken = records.find((entry) => entry.valid === false);
  if (broken !== undefined) {
    return { result: 'BLOCKED', needsRun: false, reason: `执行记录无法解析：${path.relative(projectRoot, broken.file).split(path.sep).join('/')}` };
  }

  // 连续失败达到重试上限：停止自动重跑，转 BLOCKED 交用户决策（见 e2e-run 的同名限制）。
  const failures = consecutiveFailures(records);
  const retryLimitReached = failures >= maxAttempts;
  const limitReason = `E2E 已连续失败 ${failures} 次，达到重试上限 ${maxAttempts} 次（x-agentic.e2e.maxAttempts）；停止自动重跑，须用户介入（提高上限或调整方案）后再执行`;

  const expected = normalizeCommand(configuredCommand);
  // 候选记录不参与最终判定；配置了命令时必须由该命令自动执行，命令不一致的记录不算数。
  const relevant = records.filter((entry) => {
    if (entry.stage === 'candidate') return false;
    if (expected !== '') return entry.kind === 'automated' && normalizeCommand(entry.command) === expected;
    return true;
  });

  if (relevant.length === 0) {
    if (retryLimitReached) return { result: 'BLOCKED', needsRun: false, reason: `${limitReason}（当前也无成功记录）` };
    const candidateOnly = records.length > 0 && records.every((entry) => entry.stage === 'candidate');
    if (candidateOnly) {
      return { result: 'FAIL', needsRun: true, reason: 'mode 为 required，但只有候选阶段记录；最终 E2E 需要一次 stage=final（或未标注）的成功执行' };
    }
    if (expected !== '') {
      const how = records.some((entry) => entry.kind === 'manual' && entry.stage !== 'candidate')
        ? '成功执行记录全部为人工记录或命令不一致'
        : '没有由该命令自动执行的成功执行记录';
      return { result: 'FAIL', needsRun: true, reason: `已配置 x-agentic.e2e.command，但${how}（期望 command: ${configuredCommand}）；required 须由该命令自动执行并留证` };
    }
    const seen = records.length === 0 ? '没有任何执行记录' : `已有 ${records.length} 条记录，但均未成功`;
    return { result: 'FAIL', needsRun: true, reason: `mode 为 required 但${seen}` };
  }

  const latest = relevant[0];
  try {
    const currentContract = await optionalContractDigest(changeRoot);
    if (currentContract !== null && latest.contractDigest !== currentContract) {
      if (retryLimitReached) return { result: 'BLOCKED', needsRun: false, reason: `${limitReason}；规划契约也已改变` };
      return { result: 'FAIL', needsRun: true, reason: '需求/设计/计划/任务契约已改变或记录未绑定契约；须重新评估并重跑 E2E' };
    }
  } catch (error) {
    return { result: 'BLOCKED', needsRun: false, reason: `无法核对规划契约：${error.message}` };
  }
  if (latest.status !== 'pass') {
    if (retryLimitReached) return { result: 'BLOCKED', needsRun: false, reason: `${limitReason}（最近一次仍未通过）` };
    const detail = latest.exitCode === null || latest.exitCode === undefined ? '无退出码' : `退出码 ${latest.exitCode}`;
    return { result: 'FAIL', needsRun: true, reason: `最近一次相关 E2E 尝试未通过（${latest.status}，${detail}）；更新的失败不会被更早的成功记录覆盖，需修复后重跑并写新记录` };
  }

  const freshness = evaluateRecordFreshness(projectRoot, changeRoot, latest);
  if (freshness.verdict === 'stale') {
    return { result: 'FAIL', needsRun: true, reason: `成功记录停在 ${latest.commit}，之后 ${freshness.reason}；需重跑 E2E 并写新记录` };
  }
  if (freshness.verdict === 'unknown') {
    return { result: 'BLOCKED', needsRun: false, reason: `无法核对成功记录与当前目标版本（${freshness.reason}）；required 须证明记录对当前版本有效，重跑无法修复此问题` };
  }
  const kind = latest.kind === 'manual' ? `人工记录（执行人 ${latest.executor}）` : '自动执行记录';
  const stage = latest.stage === 'final' ? '（最终阶段）' : '';
  const version = '版本一致';
  return { result: 'PASS', needsRun: false, reason: `mode 为 required，已有成功${kind}${stage}，${version}` };
}

/**
 * required 变更必须在流程内执行过 E2E 并留下记录：
 * 无成功记录 → FAIL；配置了 command 却只有人工记录 → FAIL；记录所在版本之后又有代码改动 → FAIL。
 */
async function judgeRequiredRecord({ record, changeRoot, projectRoot, configuredCommand, maxAttempts = E2E_DEFAULTS.maxAttempts }) {
  const records = await readE2ERecords(changeRoot);
  const assessment = await assessRequiredEvidence({ records, projectRoot, changeRoot, configuredCommand, maxAttempts });
  const reason = assessment.needsRun
    ? `${assessment.reason}；先在流程内运行 openspec-agentic e2e run --change ${record.name}`
    : assessment.reason;
  return { ...record, result: assessment.result, reason };
}

/** 把 --run-if-missing 的实际动作并入结论，避免“已执行”或“无法执行”被隐藏。 */
function annotatePreRun(record, preRun, projectRoot) {
  if (!preRun || preRun.status === undefined) return record;
  if (preRun.status === 'pass') {
    const relative = preRun.recordPath === undefined ? '' : `（${path.relative(projectRoot, preRun.recordPath).split(path.sep).join('/')}）`;
    return { ...record, reason: `${record.reason}；--run-if-missing 已执行 E2E 并写记录${relative}` };
  }
  if (preRun.status === 'blocked') {
    return { ...record, reason: `${record.reason}；--run-if-missing 无法执行：${preRun.reason}` };
  }
  return record;
}

/**
 * --run-if-missing 的前置动作：仅对 agentic 且 mode 为 required、证据待补的变更真实执行
 * x-agentic.e2e.command 并写记录；输出走 stderr，保证 e2e check --json 的 stdout 仍是纯 JSON。
 * 判定仍由 inspectChange 统一给出。
 */
async function ensureRequiredEvidence({ name, projectRoot, packageRoot, configuredCommand, maxAttempts = E2E_DEFAULTS.maxAttempts, planningRoot = null, write = true }) {
  const resolved = await resolveChangeRoot({ projectRoot, packageRoot, changeName: name, planningRoot });
  if (resolved.error !== undefined) return null;
  const { changeRoot } = resolved;
  let planText = null;
  try {
    planText = await fs.readFile(path.join(changeRoot, 'plan.md'), 'utf8');
  } catch {
    return null;
  }
  const fields = parseMainE2EFields(planText);
  if (fields === null || fields.mode !== MODE_REQUIRED) return null;
  const records = await readE2ERecords(changeRoot);
  const assessment = await assessRequiredEvidence({ records, projectRoot, changeRoot, configuredCommand, maxAttempts });
  if (!assessment.needsRun) return null;
  if (!write) return null;
  return runE2E({ projectRoot, packageRoot, changeName: name, stage: 'final', planningRoot, settings: { command: configuredCommand, maxAttempts }, stream: 'stderr' });
}

/**
 * 检查未归档变更与项目开关的一致性。
 * 全部完成后（引擎 list 的 status 为 complete）才参与判定；查全部模式下进行中的变更记为
 * IN_PROGRESS 不阻断，指定 changeName 时未完成即 BLOCKED（见 inspectChange）。
 * required 变更还要求存在成功的执行记录（见 judgeRequiredRecord）。
 * runIfMissing 为 true 时，先对证据待补的 required 变更真实执行 x-agentic.e2e.command 再判定。
 * 每个变更需要一次引擎调用，未指定 changeName 时按变更数线性增长。
 */
export async function checkE2E({ projectRoot, packageRoot, changeName = null, runIfMissing = false, planningRoot = null, write = true }) {
  const engineRoot = planningRoot ?? projectRoot;
  const settings = resolveE2EConfig({ projectRoot: engineRoot });
  const result = {
    configPath: settings.configPath,
    enabled: settings.enabled,
    command: settings.command,
    maxAttempts: settings.maxAttempts,
    result: 'PASS',
    changes: [],
    errors: [...settings.errors],
  };

  const listed = await runEngine({ targetPath: engineRoot, packageRoot, args: ['list', '--json'], capture: true });
  const inventory = listed.status === 0 ? parseJson(listed.stdout) : null;
  if (inventory === null || !Array.isArray(inventory.changes)) {
    result.result = 'BLOCKED';
    result.errors.push(`无法读取变更清单（openspec list --json 退出码 ${listed.status}）：${firstLine(listed.stderr)}`);
    return result;
  }

  const inventory_ = inventory.changes;
  if (changeName !== null && !inventory_.some((change) => change.name === changeName)) {
    result.changes.push({ name: changeName, complete: false, result: 'BLOCKED', reason: '未在未归档变更中找到该名称（已归档变更不参与检查）' });
    result.result = 'BLOCKED';
    return result;
  }

  const targets = changeName === null ? inventory_.map((change) => change.name) : [changeName];
  const preRuns = new Map();
  if (runIfMissing) {
    for (const name of targets) {
      preRuns.set(name, await ensureRequiredEvidence({ name, projectRoot, packageRoot, configuredCommand: settings.command, maxAttempts: settings.maxAttempts, planningRoot, write }));
    }
  }
  for (const name of targets) {
    const entry = inventory_.find((change) => change.name === name);
    result.changes.push(await inspectChange({
      name,
      complete: entry?.status === 'complete',
      projectRoot,
      packageRoot,
      enabled: settings.enabled,
      configuredCommand: settings.command,
      maxAttempts: settings.maxAttempts,
      requireComplete: changeName !== null,
      preRun: preRuns.get(name) ?? null,
      planningRoot,
      write,
    }));
  }
  result.result = bySeverity(result.changes);
  return result;
}
