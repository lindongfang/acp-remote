# Agentic workflow

本项目的 agentic 变更使用 [.agents/skills/agentic-verify/SKILL.md](.agents/skills/agentic-verify/SKILL.md)
作为最终验收入口。执行 `/opsx:verify`、最终验收或归档前检查时，先读取该 skill；
其他 schema 沿用自身流程。宿主没有 skill 发现能力时，也应直接读取该文件。

OpenSpec 流程中的 CLI 状态 `all_done` 只表示任务复选框完成。收到该状态后，若要报告 agentic 变更
可归档，仍须执行上述验收；不得仅凭 CLI 的默认归档提示形成验收结论。
保留 CLI 原始状态，另行报告证据验收的 PASS / FAIL / BLOCKED。

本规则不授权合并、推送、回滚、发布或归档。普通项目审查、schema 编辑不要求执行产品变更的验收流程。
